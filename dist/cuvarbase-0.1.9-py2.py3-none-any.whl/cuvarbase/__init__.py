import pycuda.autoinit
__version__ = "0.1.9"

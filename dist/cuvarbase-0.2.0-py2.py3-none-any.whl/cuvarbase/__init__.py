import pycuda.autoinit
__version__ = "0.2.0"

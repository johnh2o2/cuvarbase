#!/usr/bin/env python3
"""Independently decode retained diagnostic vectors; never change a study gate."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np


def digest(array):
    array = np.ascontiguousarray(array)
    value = hashlib.sha256()
    value.update(json.dumps(array.dtype.str).encode())
    value.update(json.dumps(array.shape).encode())
    value.update(array.tobytes())
    return value.hexdigest()


def load_run(folder):
    record = json.loads((folder/'record.json').read_text())
    raw = (folder/'vectors.json').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == record['compact_vectors_sha256']
    vectors = {}
    for key, item in json.loads(raw).items():
        value = np.frombuffer(bytes.fromhex(item['data_hex']),
                              dtype=item['dtype_str']).reshape(item['shape'])
        assert digest(value) == item['sha256'] == record['arrays'][key]['sha256']
        assert str(value.dtype) == item['dtype'] == record['arrays'][key]['dtype']
        assert list(value.shape) == item['shape'] == record['arrays'][key]['shape']
        vectors[key] = value
    return record, vectors


def compare(a, b):
    assert a.keys() == b.keys()
    differences = {}
    for key in a:
        x, y = a[key], b[key]
        if x.dtype != y.dtype or x.shape != y.shape:
            differences[key] = dict(shape_dtype_equal=False)
            continue
        if x.tobytes() == y.tobytes():
            continue
        raw_x = np.ascontiguousarray(x).view(np.uint8).reshape(x.size, x.dtype.itemsize)
        raw_y = np.ascontiguousarray(y).view(np.uint8).reshape(y.size, y.dtype.itemsize)
        indices = np.flatnonzero(np.any(raw_x != raw_y, axis=1))
        finite = np.isfinite(x) & np.isfinite(y)
        delta = np.abs(x[finite].astype(float)-y[finite].astype(float))
        differences[key] = dict(changed_cells=len(indices),
            first_indices=indices[:12].tolist(),
            max_finite_abs_error=float(delta.max()) if delta.size else None)
    return differences


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, required=True)
    parser.add_argument('--expected', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    expected = json.loads(args.expected.read_text())
    terminal = json.loads((args.results/'terminal.json').read_text())
    assert terminal['exit_code'] == 0 and terminal['scientific_gate_pass'] is None
    groups = ('gtls', 'gtls_corrected', 'candidate')
    runs, output = {}, dict(classification='independent diagnostic review',
        scientific_gate_changed=False, original_control_gate_pass=False,
        same_host_repeats={}, same_host_pairs=[], versus_original_A6000={},
        inventory_verified_files=0)
    inventory = json.loads((args.results/'inventory.json').read_text())
    missing = []
    for name, item in inventory.items():
        path = args.results/name
        if not path.exists():
            missing.append(name)
            continue
        raw = path.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == item['sha256'] and len(raw) == item['bytes']
        output['inventory_verified_files'] += 1
    assert not [name for name in missing if not name.endswith('.npz')]
    output['uncollected_optional_npz'] = missing
    for group in groups:
        identity = json.loads((args.results/group/'identity.json').read_text())
        for key in ('input_sha256', 'production_sources', 'native_sources', 'validation_sources'):
            assert identity[key] == expected[key]
        runs[group] = [load_run(args.results/group/('run%d' % i)) for i in range(3)]
        output['same_host_repeats'][group] = [compare(runs[group][0][1], item[1]) for item in runs[group][1:]]
        original = expected['original_records'][group]
        output['versus_original_A6000'][group] = [dict(
            differing_array_hashes=[key for key, value in record['arrays'].items()
                if key in original['arrays'] and value['sha256'] != original['arrays'][key]['sha256']],
            period=record['result']['period'], SDE=record['result']['score'],
            same_original_period=record['result']['period'] == original['result']['period'],
            same_original_SDE=record['result']['score'] == original['result']['score'])
            for record, _ in runs[group]]
    for i in range(3):
        a, b = runs['gtls_corrected'][i], runs['candidate'][i]
        shared = set(a[1]) & set(b[1])
        output['same_host_pairs'].append(dict(
            differing_shared_vectors=compare({k:a[1][k] for k in shared}, {k:b[1][k] for k in shared}),
            same_period=a[0]['result']['period'] == b[0]['result']['period'],
            same_SDE=a[0]['result']['score'] == b[0]['result']['score']))
    output['captured_rows'] = json.loads((args.results/'all-row-input-comparisons.json').read_text())['mismatching_rows']
    summary = json.loads((args.results/'scan-kernels/summary.json').read_text())
    output['scan_kernel_rows'] = [{key: row[key] for key in (
        'row', 'period', 'unique_scan_outputs', 'actual_input_comparisons',
        'native_graph_first', 'saved_native_versus_repeat', 'saved_candidate_versus_repeat',
        'same_input_kernels', 'candidate_saved_input_kernels', 'prefix_only_window_effects')}
        for row in summary['rows']]
    output['scope'] = ('Repeated executions on the diagnostic host do not replace the original '
                       'A6000 outcome and are not independent sensitivity samples.')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(output, indent=2, allow_nan=False)+'\n')
    print(json.dumps({key:value for key,value in output.items() if key != 'scan_kernel_rows'}, indent=2))


if __name__ == '__main__':
    main()

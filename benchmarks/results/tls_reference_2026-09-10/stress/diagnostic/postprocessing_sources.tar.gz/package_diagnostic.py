#!/usr/bin/env python3
"""Publish compact original numerical diagnostic receipts and source identities."""
import argparse
import csv
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile
import xml.etree.ElementTree as ET

import numpy as np

from review_probe import digest, load_run


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def archive(path, files):
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w') as output:
        for name, source in sorted(files.items()):
            data = source.read_bytes()
            item = tarfile.TarInfo(name)
            item.size, item.mode, item.mtime = len(data), 0o644, 0
            output.addfile(item, io.BytesIO(data))
    with path.open('wb') as target, gzip.GzipFile(fileobj=target, mode='wb', mtime=0, filename='') as stream:
        stream.write(raw.getvalue())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--results', type=Path, required=True)
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--sources', type=Path, required=True)
    parser.add_argument('--environment', type=Path, required=True)
    parser.add_argument('--review', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError('Use a new publication directory')
    terminal = json.loads((args.results/'terminal.json').read_text())
    assert terminal['exit_code'] == 0 and terminal['scientific_gate_pass'] is None
    expected = json.loads((args.sources/'expected.json').read_text())
    assert sha(args.input) == expected['input_sha256']
    with np.load(args.input, allow_pickle=False) as loaded:
        inputs = {key:loaded[key] for key in loaded.files if key != 'metadata'}
        metadata = json.loads(str(loaded['metadata']))
    inputs['t'] = inputs['t']-(np.floor(inputs['t'].min())-1.)
    for backend in ('gtls', 'gtls_corrected', 'candidate', 'capture_gtls_corrected', 'capture_candidate'):
        identity = json.loads((args.results/backend/'identity.json').read_text())
        assert identity['search_kwargs'] == metadata['search_kwargs']
        for key, value in inputs.items():
            assert identity['transformed_inputs'][key]['sha256'] == digest(value)
        for key in ('input_sha256', 'production_sources', 'native_sources', 'validation_sources'):
            assert identity[key] == expected[key]
    inventory = json.loads((args.results/'inventory.json').read_text())
    for name, item in inventory.items():
        source = args.results/name
        assert source.stat().st_size == item['bytes'] and sha(source) == item['sha256']
    rows, records, fit_fields = [], [], None
    for backend in ('gtls', 'gtls_corrected', 'candidate'):
        for repetition in range(3):
            folder = args.results/backend/('run%d' % repetition)
            record, values = load_run(folder)
            periods = values['periods']
            truth = int(np.flatnonzero(periods == metadata['truth_period'])[0])
            selected = int(np.flatnonzero(periods == record['result']['period'])[0])
            row = dict(backend=backend, repetition=repetition,
                original_record_sha256=sha(folder/'record.json'),
                selected_period_days=record['result']['period'],
                SDE=record['result']['score'],
                selected_over_true_period=record['result']['period']/metadata['truth_period'])
            for stage, key, mask_key in [('coarse', 'coarse_chi2', 'coarse_chi2_mask'), ('final', 'chi2', 'chi2_mask')]:
                value, mask = values[key], values[mask_key]
                row[stage+'_truth_masked'] = bool(mask[truth])
                row[stage+'_truth_chi2'] = float(value[truth])
                row[stage+'_selected_chi2'] = float(value[selected])
                row[stage+'_truth_tied_rank'] = None if mask[truth] else 1+int(np.count_nonzero((~mask) & (value < value[truth])))
                row[stage+'_truth_selected_tie'] = bool(not mask[truth] and not mask[selected] and value[truth] == value[selected])
            rows.append(row)
            records.append(record)
            keys = set(record['result']['final_fit'])
            fit_fields = keys if fit_fields is None else fit_fields & keys
    shared_fits_equal = all(all(record['result']['final_fit'][key] == records[0]['result']['final_fit'][key]
                               for key in fit_fields) for record in records[1:])
    scan = json.loads((args.results/'scan-kernels/summary.json').read_text())
    scan_summary = []
    for row in scan['rows']:
        effects = row['prefix_only_window_effects']
        assert all(item['window_comparison']['bitwise'] and item['packed_minimum_bitwise'] and item['packed_winner_equal'] for item in effects)
        scan_summary.append(dict(row=row['row'], period=row['period'],
            unique_scan_outputs=row['unique_scan_outputs'],
            same_input_kernels_bitwise=row['same_input_kernels']['window_comparison']['bitwise'],
            candidate_saved_input_kernels_bitwise=row['candidate_saved_input_kernels']['window_comparison']['bitwise'],
            prefix_only_outcomes=[{key:item[key] for key in (
                'native_minimum', 'native_start', 'native_width',
                'changed_mean_depth_gates_all_starts', 'changed_mean_depth_gates_evaluated_starts')}
                for item in effects]))
    original = json.loads(args.review.read_text())
    assert original['inventory_verified_files'] == len(inventory) and not original['uncollected_optional_npz']
    gpu = ET.fromstring((args.environment/'gpu.xml').read_text())
    environment = dict(runtime=json.loads((args.environment/'runtime.json').read_text()),
        gpu_name=gpu.findtext('gpu/product_name'), driver_version=gpu.findtext('driver_version'),
        driver_cuda_support=gpu.findtext('cuda_version'),
        original_gpu_xml_sha256=sha(args.environment/'gpu.xml'),
        original_runtime_sha256=sha(args.environment/'runtime.json'),
        original_dependency_freeze_sha256=sha(args.environment/'freeze.txt'),
        hardware_scope='Another RTX A6000 host; not the original physical host')
    args.out.mkdir(parents=True)
    compact = {str(path.relative_to(args.results)):path for path in args.results.rglob('*') if path.is_file() and path.suffix in ('.json', '.log')}
    archive(args.out/'records.tar.gz', compact)
    shutil.copyfile(args.sources/'execution-sources-v3.tar.gz', args.out/'execution-sources-v3.tar.gz')
    shutil.copyfile(args.sources/'execution-sources-v3.json', args.out/'source_manifest.json')
    postprocessing = {path.name:path for path in [Path(__file__), Path(__file__).with_name('review_probe.py')]}
    archive(args.out/'postprocessing_sources.tar.gz', postprocessing)
    write(args.out/'environment.json', environment)
    shutil.copyfile(args.environment/'freeze.txt', args.out/'dependencies.txt')
    with (args.out/'runs.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    write(args.out/'summary.json', dict(
        classification='Focused diagnostic repeated execution on one original development input',
        original_control_gate_pass=False, scientific_gate_changed=False,
        independent_scientific_samples_added=0, input_sha256=expected['input_sha256'],
        original_input_metadata=metadata, full_uncaptured_runs=9, full_captured_runs=2,
        captured_periods=97, selected_rows=scan_summary,
        all_selected_periods_days=sorted(set(row['selected_period_days'] for row in rows)),
        shared_final_fit_fields=sorted(fit_fields), shared_final_fit_fields_equal=shared_fits_equal,
        all_truth_and_selected_coarse_final_chi2_tie=all(row['coarse_truth_selected_tie'] and row['final_truth_selected_tie'] for row in rows),
        all_final_truth_tied_rank_one=all(row['final_truth_tied_rank'] == 1 for row in rows),
        SDE_by_method={method:[row['SDE'] for row in rows if row['backend']==method] for method in ('gtls','gtls_corrected','candidate')},
        captured_differing_rows=original['captured_rows'],
        full_collected_inventory_files=len(inventory), compact_published_original_files=len(compact),
        unpublished_collected_npz={name:item for name,item in inventory.items() if name.endswith('.npz')},
        all_original_files_hash_verified=True,
        original_inventory_sha256=sha(args.results/'inventory.json'),
        original_terminal_sha256=sha(args.results/'terminal.json'),
        packaging_source_sha256=sha(Path(__file__)), reviewer_source_sha256=sha(Path(__file__).with_name('review_probe.py')),
        limits=['Original failed exact comparison remains failed',
                'The selected grid contains truth and aliases; this is not blind recovery evidence',
                'Native and graph float32 prefix variability can change depth gates, masks and final SDE',
                'Stable candidate full repeats do not imply deterministic graph scans or universal parity',
                'Same-prefix kernel agreement is limited to the inspected rows and variants',
                'Diagnostic elapsed time is not a performance measurement']))
    write(args.out/'files.json', {path.name:dict(bytes=path.stat().st_size, sha256=sha(path)) for path in sorted(args.out.iterdir()) if path.is_file()})
    print(json.dumps(dict(output=str(args.out), original_files_verified=len(inventory),
        published_bytes=sum(p.stat().st_size for p in args.out.iterdir()), same_final_fit=shared_fits_equal,
        all_truth_selected_tie=all(row['coarse_truth_selected_tie'] and row['final_truth_selected_tie'] for row in rows))))


if __name__ == '__main__':
    main()

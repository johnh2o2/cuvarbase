#!/usr/bin/env python3
"""Bounded, private long-control diagnosis; never a benchmark or acceptance gate.

Unchanged public searches run in isolated backend processes first. Additional
captured runs synchronize/copy intermediate arrays and can change scheduling;
their results are explicitly separate. No tolerances or production edits occur.
"""
import argparse
import hashlib
import importlib
import inspect
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback

import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def plain(value):
    if isinstance(value, np.ndarray):
        return plain(value.tolist())
    if isinstance(value, np.generic):
        return plain(value.item())
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [plain(v) for v in value]
    if isinstance(value, float) and not np.isfinite(value):
        return None
    return value


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(plain(value), indent=2, allow_nan=False) + '\n')
    tmp.replace(path)


def digest(value):
    value = np.ascontiguousarray(value)
    h = hashlib.sha256()
    h.update(json.dumps(value.dtype.descr if value.dtype.names else value.dtype.str).encode())
    h.update(json.dumps(value.shape).encode())
    h.update(value.tobytes())
    return dict(sha256=h.hexdigest(), dtype=str(value.dtype), shape=list(value.shape))


def difference(reference, candidate, limit=12):
    a, b = np.asarray(reference), np.asarray(candidate)
    if a.dtype != b.dtype or a.shape != b.shape:
        return dict(bitwise=False, shape_equal=a.shape == b.shape,
                    dtype_equal=a.dtype == b.dtype)
    # Byte comparisons include signed zero and NaN payloads.
    av = np.ascontiguousarray(a).view(np.uint8).reshape(a.size, a.dtype.itemsize)
    bv = np.ascontiguousarray(b).view(np.uint8).reshape(b.size, b.dtype.itemsize)
    indices = np.flatnonzero(np.any(av != bv, axis=1))
    result = dict(bitwise=len(indices) == 0, changed_cells=len(indices),
                  indices=indices[:limit].tolist(), truncated=len(indices) > limit,
                  reference=digest(a), candidate=digest(b))
    if a.dtype.kind in 'biufc':
        flat_a, flat_b = a.ravel(), b.ravel()
        finite = np.isfinite(flat_a) & np.isfinite(flat_b)
        result['max_absolute_difference'] = float(np.max(np.abs(
            flat_a[finite].astype(np.float64) - flat_b[finite].astype(np.float64)))) if finite.any() else 0.
        result['reference_values'] = flat_a[indices[:limit]].tolist()
        result['candidate_values'] = flat_b[indices[:limit]].tolist()
    return result


def load_input(path):
    with np.load(path, allow_pickle=False) as source:
        data = {key: source[key].copy() for key in source.files if key != 'metadata'}
        metadata = json.loads(str(source['metadata']))
    finite = data['t'][np.isfinite(data['t'])]
    shift = float(np.floor(np.min(finite)) - 1.)
    data['t'] = data['t'] - shift
    return data, metadata, shift


def modules(root):
    sys.path.insert(0, str(root / 'validation'))
    sys.path.insert(0, str(root / 'candidate'))
    import parity_harness as harness
    return harness


def verify_sources(args, harness):
    import gputls
    expected = json.loads(args.expected.read_text())
    actual = dict(input_sha256=sha(args.input),
                  production_sources=harness.production_sources(args.root / 'candidate'),
                  native_sources=harness.sources(Path(gputls.__file__).parent),
                  validation_sources={key: sha(args.root / 'validation' / key)
                                      for key in expected['validation_sources']})
    for key, value in actual.items():
        if value != expected[key]:
            raise ValueError('Frozen diagnostic identity differs: ' + key)
    return actual


def small_arrays(arrays):
    return {key: value for key, value in arrays.items()
            if np.asarray(value).size <= 10000 and not key.startswith('cache_')}


def compact_vectors(arrays):
    """Exact small arrays, recoverable through the required JSON-only backup."""
    result = {}
    for key, value in small_arrays(arrays).items():
        value = np.ascontiguousarray(value)
        if value.dtype.hasobject or value.dtype.names:
            raise TypeError('Only plain numeric vectors may use this compact encoding')
        result[key] = dict(digest(value), dtype_str=value.dtype.str,
                           encoding='C-order bytes as hexadecimal', data_hex=value.tobytes().hex())
    return result


def save_run(folder, arrays, result, elapsed, instrumented):
    folder.mkdir(parents=True, exist_ok=False)
    path = folder / 'vectors.npz'
    np.savez_compressed(path, **small_arrays(arrays))
    vector_json = folder / 'vectors.json'
    write(vector_json, compact_vectors(arrays))
    record = dict(status='ok', instrumented_intermediate_capture=instrumented,
                  operational_seconds=elapsed, timing_claim=False, result=result,
                  arrays={key: digest(value) for key, value in arrays.items()},
                  vectors_file=path.name, vectors_sha256=sha(path),
                  compact_vectors_file=vector_json.name, compact_vectors_sha256=sha(vector_json))
    write(folder / 'record.json', record)
    return record


class NativeCapture:
    """Observe actual native coarse cumsums; numerical expressions unchanged."""
    def __init__(self, cp, nperiods, selected):
        self.cp, self.nperiods, self.selected = cp, nperiods, set(selected)
        self.records, self.buffers = {}, {}

    def __enter__(self):
        self.original = self.cp.cumsum

        def spy(value, *args, **kwargs):
            result = self.original(value, *args, **kwargs)
            frame = sys._getframe(1)
            if frame.f_code.co_name != 'search_multi_periods':
                return result
            local = frame.f_locals
            if 'iterFlag' not in local or 'singleCalcPeriods' not in local:
                return result
            start = int(local['iterFlag']) * int(local['singleCalcPeriods'])
            if value.ndim == 1 and kwargs.get('axis') is None:
                row = int(local['i'])
                index = start + row
                if index >= self.nperiods:
                    return result
                mapping = dict(phases=local['phasesGPU'][row], order=local['sortIndexGPU'][row],
                               flux=local['patchedDatasGPU'][row],
                               invvar=local['inverseSquaredPatchedDysGPU'][row],
                               edge=local['edgeEffectCorrectionsGPU'][row:row+1], prefix=result)
                self._save(index, mapping)
                if index in self.selected:
                    self.buffers['row%d_workspace_rows' % index] = np.int32(local['singleCalcPeriods'])
                    self.buffers['row%d_workspace_row' % index] = np.int32(row)
            elif value.ndim == 2 and kwargs.get('axis') == 1:
                for row in range(min(value.shape[0], self.nperiods - start)):
                    self._save(start + row, dict(error_prefix=result[row], base_error=value[row]))
            return result

        self.cp.cumsum = spy
        return self

    def _save(self, index, mapping):
        record = self.records.setdefault(index, {})
        for key, value in mapping.items():
            array = value.get()
            record[key] = digest(array)
            if index in self.selected:
                self.buffers['row%d_%s' % (index, key)] = array

    def __exit__(self, *exc):
        self.cp.cumsum = self.original


class CandidateCapture:
    def __init__(self, engine, selected):
        self.engine, self.selected = engine, set(selected)
        self.records, self.buffers = {}, {}

    def __enter__(self):
        self.original = self.engine.raw_search

        def spy(*args, **kwargs):
            coarse = not kwargs.get('full', False)
            if coarse:
                kwargs['capture'] = True
            result = self.original(*args, **kwargs)
            if coarse:
                for chunk in result.pop('captured'):
                    for row, index in enumerate(range(chunk['start'], chunk['stop'])):
                        record = self.records.setdefault(index, {})
                        for key in ('phases', 'order', 'flux', 'invvar', 'prefix', 'error_prefix', 'edge'):
                            array = np.atleast_1d(chunk[key][row])
                            record[key] = digest(array)
                            if index in self.selected:
                                self.buffers['row%d_%s' % (index, key)] = array.copy()
                        if index in self.selected:
                            self.buffers['row%d_workspace_rows' % index] = np.int32(chunk['stop']-chunk['start'])
                            self.buffers['row%d_workspace_row' % index] = np.int32(row)
            return result

        self.engine.raw_search = spy
        return self

    def __exit__(self, *exc):
        self.engine.raw_search = self.original


def backend_child(args):
    import cupy as cp
    harness = modules(args.root)
    identity = verify_sources(args, harness)
    data, metadata, shift = load_input(args.input)
    if metadata['search_kwargs'] != json.loads(args.expected.read_text())['search_kwargs']:
        raise ValueError('Actual metadata search kwargs differ from frozen diagnostic')
    selected = [int(x) for x in args.selected.split(',') if x]
    args.output.mkdir(parents=True, exist_ok=False)
    write(args.output / 'identity.json', dict(identity, positive_origin_shift=shift,
          transformed_inputs={k: digest(v) for k, v in data.items()},
          options={}, search_kwargs=metadata['search_kwargs'], mode='full', work_chunk=256))
    records = []
    for repetition in range(1 if args.capture else args.repeats):
        capture = None
        if args.capture:
            capture = (NativeCapture(cp, len(data['periods']), selected) if args.backend != 'candidate'
                       else CandidateCapture(importlib.import_module('cuvarbase.tls_reference'), selected))
            capture.__enter__()
        begin = time.perf_counter()
        try:
            if args.backend == 'candidate':
                arrays, result = harness.run_candidate(data, {}, 'full', args.root / 'candidate',
                    None, 256, chunk_policy='default', engine_kind='public',
                    auto_grid=False, case_search_kwargs=metadata['search_kwargs'])
            else:
                arrays, result = harness.run_gtls(data, {}, 'full', auto_grid=False,
                    case_search_kwargs=metadata['search_kwargs'], correction=args.backend == 'gtls_corrected')
            cp.cuda.runtime.deviceSynchronize()
        finally:
            if capture is not None:
                capture.__exit__(None, None, None)
        records.append(save_run(args.output / ('run%d' % repetition), arrays, result,
                                time.perf_counter() - begin, args.capture))
        prior = json.loads(args.expected.read_text())['original_records'][args.backend]
        write(args.output / ('run%d' % repetition) / 'versus_original.json', dict(
            arrays={key: digest(value)['sha256'] == prior['arrays'][key]['sha256']
                    for key, value in arrays.items() if key in prior['arrays']},
            selected_period_equal=result['period'] == prior['result']['period'],
            selected_SDE_equal=result['score'] == prior['result']['score']))
        if capture is not None:
            expected_indices = set(range(len(data['periods'])))
            if set(capture.records) != expected_indices:
                raise ValueError('Intermediate capture omitted logical periods')
            capture.buffers.update({key: arrays[key] for key in
                ('cache_widths', 'cache_template_deficits', 'cache_overshoot',
                 'stage0_chunk_width_masks', 'periods')})
            capture.buffers['ndata'] = np.int32(len(arrays['prepared_t']))
            capture.buffers['group_size'] = np.int32(result['group_size'])
            np.savez_compressed(args.output / 'selected-buffers.npz', **capture.buffers)
            write(args.output / 'row-hashes.json', capture.records)
        write(args.output / 'progress.json', dict(status='running', completed=len(records)))
    verify_sources(args, harness)
    write(args.output / 'terminal.json', dict(status='complete', exit_code=0,
          repetitions=len(records), instrumented_intermediate_capture=args.capture))


def packed_tiles(cp, widths, ndata):
    duration, first = [], []
    for d, width in enumerate(widths):
        skip = max(int(width) // 8, 1)
        for j in range(0, (ndata + skip - 1) // skip, 256):
            duration.append(d)
            first.append(j)
    return cp.asarray(duration, dtype=cp.int32), cp.asarray(first, dtype=cp.int32)


GATE_SOURCE = r'''
extern "C" __global__ void count_gate_changes(const float* a,const float* b,
 const int* widths,int ndata,int nd,unsigned int* counts) {
 int j=blockIdx.x*blockDim.x+threadIdx.x,d=blockIdx.y;
 if(j>=ndata||d>=nd)return;
 int w=widths[d];
 float da=1.0f-(j==0?a[w-1]:a[j+w-1]-a[j-1])/w;
 float db=1.0f-(j==0?b[w-1]:b[j+w-1]-b[j-1])/w;
 if((da>1.e-5f)!=(db>1.e-5f)) {
  atomicAdd(counts,1u);
  int skip=w>8?w/8:1;
  if(j%skip==0)atomicAdd(counts+1,1u);
 }
}
'''


def window_probe(cp, native, fused, saved, row, prefixes=None):
    """Same saved inputs, full logical coarse window tensor and packed winner."""
    ndata, group = int(saved['ndata']), int(saved['group_size'])
    ids = np.flatnonzero(saved['stage0_chunk_width_masks'][row // group])
    widths = saved['cache_widths'][ids].astype(np.int32)
    flux, invvar, prefix, error_prefix = [cp.asarray(saved['row%d_%s' % (row, key)][None, :])
        for key in ('flux', 'invvar', 'prefix', 'error_prefix')]
    if prefixes is not None:
        prefix = cp.asarray(prefixes[None, :])
    edge = cp.asarray(saved['row%d_edge' % row])
    template = cp.asarray(saved['cache_template_deficits'][ids])
    overshoot = cp.asarray(saved['cache_overshoot'][ids])
    wg = cp.asarray(widths)
    nwidths, stride, ts = len(widths), flux.shape[1], template.shape[1]
    i32, pi = np.int32, lambda value: cp.asarray([value], cp.int32)
    fullsum = cp.empty((1, nwidths), cp.float32)
    native.get_function('calcAllFullSum_v2')(((nwidths+255)//256,1),(256,),
        (fullsum,error_prefix,i32(stride),wg,i32(nwidths),i32(1)))
    shape = (1, nwidths, ndata)
    ootr = cp.empty(shape, cp.float32)
    native.get_function('calculate_final_ootr_v3')(((ndata+255)//256,nwidths,1),(256,),
        (ootr,error_prefix,fullsum,wg,i32(ndata),i32(stride),i32(nwidths),i32(1)))
    expected, observed = cp.empty(shape, cp.float32), cp.empty(shape, cp.float32)
    native.get_function('calcAllLowestResidualsGPUB_SignalTiled_v2')(
        ((ndata//128)+1,nwidths,1),(128,),
        (expected,pi(ndata),flux,pi(stride),wg,pi(nwidths),template,pi(ts),invvar,
         overshoot,ootr,fullsum,edge,pi(ndata),prefix,cp.asarray([1.e-5],cp.float32)))
    fused.get_function('tls_reference_window_values')(((ndata+255)//256,nwidths,1),(256,),
        (flux,invvar,prefix,error_prefix,edge,wg,template,overshoot,
         i32(1),i32(ndata),i32(stride),i32(nwidths),i32(ts),i32(8),np.float32(1.e-5),observed))
    tiles, first = packed_tiles(cp, widths, ndata)
    nt = len(tiles)
    partial, keys, depths = cp.empty((1,nt),cp.float32), cp.empty((1,nt),cp.uint64), cp.empty((1,nt),cp.float32)
    fused.get_function('tls_reference_search')((nt,1),(256,),
        (flux,invvar,prefix,error_prefix,edge,wg,template,overshoot,tiles,first,
         i32(1),i32(ndata),i32(stride),i32(nwidths),i32(ts),i32(nt),i32(8),
         np.float32(1.e-5),partial,keys,depths))
    minimum, start, d, width, depth = (cp.empty(1,dtype) for dtype in
                                     (cp.float32,cp.int32,cp.int32,cp.int32,cp.float32))
    fused.get_function('tls_reference_reduce')((1,),(256,),
        (partial,keys,depths,wg,i32(1),i32(ndata),i32(nt),minimum,start,d,width,depth))
    e, o = expected.get(), observed.get()
    key = int(e.argmin())
    fused_key = int(d.get()[0])*ndata + int(start.get()[0])
    return dict(row=row, period=float(saved['periods'][row]), widths=widths.tolist(),
        prefix=digest(prefix.get()), window_comparison=difference(e,o),
        native_minimum=float(e.ravel()[key]), native_key=key,
        native_start=key%ndata, native_width=int(widths[key//ndata]),
        packed_minimum=float(minimum.get()[0]), packed_key=fused_key,
        packed_minimum_bitwise=difference(e.ravel()[key:key+1],minimum.get())['bitwise'],
        packed_winner_equal=key==fused_key)


def scan_child(args):
    import cupy as cp
    from gputls.GPUFun import getGPUCode
    harness = modules(args.root)
    verify_sources(args, harness)
    from cuvarbase.tls_reference_prefix import NativePrefixPlan
    selected = [int(x) for x in args.selected.split(',') if x]
    args.output.mkdir(parents=True, exist_ok=False)
    captures = {}
    for backend in ('gtls_corrected','candidate'):
        with np.load(args.results / ('capture_'+backend) / 'selected-buffers.npz',allow_pickle=False) as loaded:
            captures[backend] = {key: loaded[key] for key in loaded.files}
    native = cp.RawModule(code=getGPUCode())
    fused = cp.RawModule(code=(args.root/'candidate/cuvarbase/kernels/tls_reference.cu').read_text())
    gates = cp.RawKernel(GATE_SOURCE, 'count_gate_changes')
    result = dict(scope='diagnostic only; original exact acceptance gates unchanged', rows=[])
    for row in selected:
        n, c = captures['gtls_corrected'], captures['candidate']
        entry = dict(row=row, period=float(n['periods'][row]), actual_input_comparisons={})
        for key in ('phases','order','flux','invvar','edge','prefix','error_prefix'):
            entry['actual_input_comparisons'][key] = difference(n['row%d_%s'%(row,key)],c['row%d_%s'%(row,key)])
        # Different pointers/launch schedules are intentional here. Each scan
        # gets the same frozen values, and every changed prefix is retained as
        # a digest and a finite sample, with no numerical tolerance.
        native_rows, candidate_rows = [int(saved['row%d_workspace_rows'%row]) for saved in (n,c)]
        native_row, candidate_row = [int(saved['row%d_workspace_row'%row]) for saved in (n,c)]
        x = cp.asarray(np.repeat(n['row%d_flux'%row][None,:],native_rows,axis=0))
        graph_x = cp.asarray(np.repeat(n['row%d_flux'%row][None,:],candidate_rows,axis=0))
        base = cp.asarray(np.repeat(n['row%d_base_error'%row][None,:],native_rows,axis=0))
        entry['scan_workspace'] = dict(native_rows=native_rows,native_row=native_row,
            candidate_rows=candidate_rows,candidate_row=candidate_row,
            companion_rows='Repeat the selected row; actual row offset/stride and number of launches are preserved.')
        first, variants = {}, {}
        summaries = []
        with NativePrefixPlan(graph_x.shape) as plan:
            for repetition in range(args.scan_repeats):
                native_outputs = [cp.cumsum(x[i]) for i in range(native_rows)]
                values = {'native': native_outputs[native_row].get(),
                          'graph': plan(graph_x).get()[candidate_row],
                          'native_error_axis1': cp.cumsum(base,axis=1).get()[native_row]}
                for label,value in values.items():
                    baseline = first.setdefault(label,value.copy())
                    variants.setdefault(label,{})[digest(value)['sha256']] = value.copy()
                    summaries.append(dict(repetition=repetition,method=label,
                        versus_first=difference(baseline,value)))
        entry['scan_repetitions'] = summaries
        entry['unique_scan_outputs'] = {key:len(value) for key,value in variants.items()}
        entry['native_graph_first'] = difference(first['native'],first['graph'])
        entry['saved_native_versus_repeat'] = difference(n['row%d_prefix'%row],first['native'])
        entry['saved_candidate_versus_repeat'] = difference(c['row%d_prefix'%row],first['graph'])
        entry['saved_error_versus_repeat'] = difference(n['row%d_error_prefix'%row],first['native_error_axis1'])
        # Materialize native/fused tensors on *identical* saved intermediate
        # arrays. Then vary only the flux prefix to locate effects of scans.
        entry['same_input_kernels'] = window_probe(cp,native,fused,n,row)
        entry['candidate_saved_input_kernels'] = window_probe(cp,native,fused,c,row)
        prefix_variants = {digest(n['row%d_prefix'%row])['sha256']:n['row%d_prefix'%row]}
        prefix_variants[digest(c['row%d_prefix'%row])['sha256']] = c['row%d_prefix'%row]
        for label in ('native','graph'):
            prefix_variants.update(variants[label])
        entry['prefix_only_window_effects'] = []
        # If a pathological input has many nondeterministic variants, retain
        # every prefix digest above and bound expensive rescoring to the first8.
        entry['prefix_variants_total'] = len(prefix_variants)
        retained = list(prefix_variants.values())[:8]
        for prefix in retained:
            effect = window_probe(cp,native,fused,n,row,prefix)
            ids=np.flatnonzero(n['stage0_chunk_width_masks'][row//int(n['group_size'])])
            widths=cp.asarray(n['cache_widths'][ids],dtype=cp.int32)
            counts=cp.zeros(2,cp.uint32)
            ndata=int(n['ndata'])
            gates(((ndata+255)//256,len(ids)),(256,),
                (cp.asarray(n['row%d_prefix'%row]),cp.asarray(prefix),widths,
                 np.int32(ndata),np.int32(len(ids)),counts))
            effect['changed_mean_depth_gates_all_starts'], effect['changed_mean_depth_gates_evaluated_starts'] = map(int,counts.get())
            entry['prefix_only_window_effects'].append(effect)
        np.savez_compressed(args.output/('row%d-scan-variants.npz'%row),
                            **{'prefix%d'%i:value for i,value in enumerate(retained)})
        result['rows'].append(entry)
        write(args.output/'summary.json',result)
    write(args.output/'terminal.json',dict(status='complete',exit_code=0,rows=len(selected)))


def vector_comparison(a_folder,b_folder):
    with np.load(a_folder/'vectors.npz',allow_pickle=False) as a, np.load(b_folder/'vectors.npz',allow_pickle=False) as b:
        keys=sorted(set(a.files)&set(b.files))
        checks={key:difference(a[key],b[key]) for key in keys}
    return dict(checks=checks,all_shared_vectors_bitwise=all(v['bitwise'] for v in checks.values()))


def selected_rows(results,nperiods,limit=4):
    outliers=set()
    for reference in ('gtls','gtls_corrected'):
        for i in range(3):
            with np.load(results/reference/('run%d'%i)/'vectors.npz',allow_pickle=False) as a, np.load(results/'candidate'/('run%d'%i)/'vectors.npz',allow_pickle=False) as b:
                outliers.update(np.flatnonzero(np.any(
                    a['coarse_chi2'].view(np.uint8).reshape(nperiods,-1) !=
                    b['coarse_chi2'].view(np.uint8).reshape(nperiods,-1),axis=1)).tolist())
    # Keep the first observed mismatch, tie-rich first period, and singleton
    # final group. Extra outliers are chosen by period index, never outcome size.
    chosen=[]
    for i in sorted(outliers)[:1]+[0,nperiods-1]+sorted(outliers):
        if i not in chosen and len(chosen)<limit:
            chosen.append(i)
    return chosen,sorted(outliers)


def orchestrate(args):
    args.output.mkdir(parents=True,exist_ok=False)
    begin=time.monotonic()
    progress=dict(status='running',steps=[],gate_changed=False,benchmark=False)
    write(args.output/'progress.json',progress)
    collection = dict(critical='All JSON/log files: exact small vectors, original/source identities, array hashes, comparisons, scalar kernel/prefix effects, terminal status.',
        exact_vector_encoding='*/run*/vectors.json records dtype_str, shape and C-order raw-byte hexadecimal; reconstruct with numpy.frombuffer(bytes.fromhex(data_hex),dtype_str).reshape(shape).',
        optional='NPZ files contain redundant compact vectors or selected large intermediate/scan arrays. Their loss does not remove the required exact coarse vectors or measured comparison receipts, but prevents further examination of those precise saved large buffers.',
        optional_npz=[], optional_collection_verified=False,
        collection_status_owner='External guard records actual transferred files; this manifest declares required versus optional content only.')
    write(args.output/'collection-manifest.json',collection)
    base=[sys.executable,str(Path(__file__).resolve()),'--root',str(args.root),
          '--input',str(args.input),'--expected',str(args.expected)]

    def launch(name,extra):
        remaining=args.max_seconds-(time.monotonic()-begin)
        if remaining<=0:
            raise TimeoutError('Diagnostic runtime budget exhausted before '+name)
        command=base+['--output',str(args.output/name)]+extra
        started=time.monotonic()
        with (args.output/(name+'.log')).open('wb') as log:
            process=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,
                                   timeout=remaining,check=False)
        progress['steps'].append(dict(name=name,exit_code=process.returncode,
                                      elapsed_seconds=time.monotonic()-started))
        write(args.output/'progress.json',progress)
        if process.returncode!=0:
            raise RuntimeError('Diagnostic child failed: '+name)
    for backend in ('gtls','gtls_corrected','candidate'):
        launch(backend,['--child','backend','--backend',backend,'--repeats','3'])
    with np.load(args.input,allow_pickle=False) as data:
        nperiods=len(data['periods'])
    selected,outliers=selected_rows(args.output,nperiods)
    comparison=dict(selected_rows=selected,all_coarse_outlier_rows=outliers,
        corrected_candidate=[vector_comparison(args.output/'gtls_corrected'/('run%d'%i),
            args.output/'candidate'/('run%d'%i)) for i in range(3)],
        repeatability={b:[vector_comparison(args.output/b/'run0',args.output/b/('run%d'%i))
                         for i in (1,2)] for b in ('gtls','gtls_corrected','candidate')})
    write(args.output/'uncaptured-comparisons.json',comparison)
    selected_text=','.join(map(str,selected))
    for backend in ('gtls_corrected','candidate'):
        launch('capture_'+backend,['--child','backend','--backend',backend,'--capture',
                                  '--selected',selected_text])
    with (args.output/'capture_gtls_corrected/row-hashes.json').open() as f:
        native=json.load(f)
    candidate=json.loads((args.output/'capture_candidate/row-hashes.json').read_text())
    checks={row:{key:native[row][key]==candidate[row].get(key) for key in native[row]
                 if key!='base_error'} for row in native}
    write(args.output/'all-row-input-comparisons.json',dict(checks=checks,
          mismatching_rows={key:[k for k,v in val.items() if not v] for key,val in checks.items() if not all(val.values())}))
    launch('scan-kernels',['--child','scan','--results',str(args.output),
                          '--selected',selected_text,'--scan-repeats','30'])
    inventory={str(p.relative_to(args.output)):dict(bytes=p.stat().st_size,sha256=sha(p))
               for p in sorted(args.output.rglob('*')) if p.is_file() and p.suffix!='.tmp'}
    collection['optional_npz']=[dict(path=name,**value) for name,value in inventory.items() if name.endswith('.npz')]
    collection['optional_npz_total_bytes']=sum(value['bytes'] for value in collection['optional_npz'])
    write(args.output/'collection-manifest.json',collection)
    inventory['collection-manifest.json']=dict(bytes=(args.output/'collection-manifest.json').stat().st_size,
                                               sha256=sha(args.output/'collection-manifest.json'))
    write(args.output/'inventory.json',inventory)
    write(args.output/'terminal.json',dict(status='complete',exit_code=0,
          elapsed_seconds=time.monotonic()-begin,diagnostic_only=True,
          scientific_gate_pass=None,requires_independent_review=True,
          retained_bytes=sum(v['bytes'] for v in inventory.values()),
          source_sha256=sha(__file__),selected_rows=selected))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--input',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--expected',type=Path)
    parser.add_argument('--max-seconds',type=float,default=180.)
    parser.add_argument('--child',choices=('backend','scan'))
    parser.add_argument('--backend',choices=('gtls','gtls_corrected','candidate'))
    parser.add_argument('--capture',action='store_true')
    parser.add_argument('--selected',default='')
    parser.add_argument('--repeats',type=int,default=3)
    parser.add_argument('--scan-repeats',type=int,default=30)
    parser.add_argument('--results',type=Path)
    args=parser.parse_args()
    if args.expected is None:
        args.expected=args.root/'diagnostic/expected.json'
    try:
        (backend_child if args.child=='backend' else scan_child if args.child=='scan' else orchestrate)(args)
    except Exception:
        write(args.output/'terminal.json',dict(status='error',exit_code=1,error=traceback.format_exc(),
              diagnostic_only=True,scientific_gate_pass=None,requires_independent_review=True))
        raise


if __name__=='__main__':
    main()

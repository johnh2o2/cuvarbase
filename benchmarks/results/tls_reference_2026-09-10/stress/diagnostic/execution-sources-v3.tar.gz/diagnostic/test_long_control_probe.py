import importlib.util
import json
from pathlib import Path
import tempfile
import types
import unittest

import numpy as np

spec = importlib.util.spec_from_file_location('probe', Path(__file__).with_name('long_control_probe.py'))
probe = importlib.util.module_from_spec(spec)
spec.loader.exec_module(probe)


class Array:
    def __init__(self, value):
        self.value = np.asarray(value)
        self.ndim = self.value.ndim
        self.shape = self.value.shape

    def __getitem__(self, key):
        return Array(self.value[key])

    def get(self):
        return self.value.copy()


class FakeCP:
    def cumsum(self, value, *args, **kwargs):
        return Array(np.cumsum(value.value, *args, **kwargs))


class ProbeTests(unittest.TestCase):
    def test_digest_matches_frozen_harness_encoding(self):
        spec = importlib.util.spec_from_file_location('frozen_harness',
            Path(__file__).parents[1] / 'validation/parity_harness.py')
        harness = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(harness)
        for value in (np.array([np.nan, -0., 0., np.inf], np.float32),
                      np.arange(12, dtype=np.int32).reshape(3, 4)[:, ::2],
                      np.array([True, False]), np.empty(0, np.float64)):
            self.assertEqual(probe.digest(value)['sha256'], harness.array_hash(value))

    def test_bitwise_diff_distinguishes_signed_zero(self):
        result = probe.difference(np.array([0.], np.float32), np.array([-0.], np.float32))
        self.assertFalse(result['bitwise'])
        self.assertEqual(result['max_absolute_difference'], 0.)
        self.assertEqual(result['changed_cells'], 1)

    def test_diff_shape_dtype_and_empty(self):
        self.assertFalse(probe.difference(np.zeros(2), np.zeros(3))['bitwise'])
        self.assertFalse(probe.difference(np.zeros(2), np.zeros(2, np.float32))['bitwise'])
        self.assertTrue(probe.difference(np.empty(0), np.empty(0))['bitwise'])

    def test_positive_origin_and_actual_metadata_kwargs(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'case.npz'
            expected = dict(period_min=.6, period_max=12.878375495285127)
            np.savez(path, t=np.array([2457000., 2457003.]), y=np.ones(2), dy=np.ones(2),
                     periods=np.array([.6, 730.5]), metadata=json.dumps(dict(
                         search_kwargs=expected, period_bounds=[.6, 730.5])))
            data, metadata, shift = probe.load_input(path)
            self.assertEqual(shift, 2456999.)
            np.testing.assert_array_equal(data['t'], [1., 4.])
            self.assertEqual(metadata['search_kwargs'], expected)

    def test_small_array_archive_excludes_large_samples_but_keeps_all_periods(self):
        arrays = dict(prepared_t=np.arange(77888), coarse_chi2=np.arange(97),
                      stage0_winning_start=np.arange(97), cache_widths=np.arange(77))
        self.assertEqual(set(probe.small_arrays(arrays)), {'coarse_chi2', 'stage0_winning_start'})

    def test_compact_vectors_roundtrip_raw_float_bits_and_masks(self):
        values = dict(coarse_chi2=np.array([0., -0., np.nan, np.inf], np.float32),
                      stage0_winning_start=np.arange(97,dtype=np.int32),
                      coarse_chi2_mask=np.array([False,True,False,True]))
        values['coarse_chi2'].view(np.uint32)[2] = 0x7fc00011
        saved = json.loads(json.dumps(probe.compact_vectors(values)))
        for key, record in saved.items():
            actual = np.frombuffer(bytes.fromhex(record['data_hex']),
                                   dtype=np.dtype(record['dtype_str'])).reshape(record['shape'])
            self.assertEqual(actual.tobytes(),values[key].tobytes())
            self.assertEqual(record['sha256'],probe.digest(actual)['sha256'])

    def test_selected_rows_preserve_first_outlier_and_first_last_controls(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            for backend in ('gtls', 'gtls_corrected', 'candidate'):
                for i in range(3):
                    path = root / backend / ('run%d' % i)
                    path.mkdir(parents=True)
                    values = np.arange(97, dtype=np.float32)
                    if backend == 'candidate':
                        values[22] += 1
                    np.savez(path / 'vectors.npz', coarse_chi2=values)
            chosen, outliers = probe.selected_rows(root, 97)
            self.assertEqual(chosen, [22, 0, 96])
            self.assertEqual(outliers, [22])

    def test_capture_uses_actual_coarse_locals_and_selected_storage(self):
        cp = FakeCP()
        original = cp.cumsum

        def search_multi_periods():
            iterFlag, singleCalcPeriods = 0, 2
            phasesGPU = Array([[.4, .1], [.6, .2]])
            sortIndexGPU = Array(np.array([[1, 0], [1, 0]], np.int32))
            patchedDatasGPU = Array(np.array([[.9, 1., .9], [1., .9, 1.]], np.float32))
            inverseSquaredPatchedDysGPU = Array(np.ones((2, 3), np.float32))
            edgeEffectCorrectionsGPU = Array(np.zeros(2, np.float32))
            for i in range(singleCalcPeriods):
                cp.cumsum(patchedDatasGPU[i])
            cp.cumsum(Array(np.ones((2, 3), np.float32)), axis=1)

        with probe.NativeCapture(cp, 2, [1]) as capture:
            search_multi_periods()
        self.assertEqual(set(capture.records), {0, 1})
        self.assertEqual(set(capture.records[0]),
            {'phases', 'order', 'flux', 'invvar', 'edge', 'prefix', 'error_prefix', 'base_error'})
        self.assertTrue(all(key.startswith('row1_') for key in capture.buffers))
        self.assertEqual(cp.cumsum, original)

    def test_candidate_capture_does_not_change_raw_numerical_arrays(self):
        expected = np.array([.2, .3], np.float32)
        options_seen = []
        chunk = dict(start=0, stop=2, ids=np.array([0]))
        for key in ('phases', 'order', 'flux', 'invvar', 'prefix', 'error_prefix'):
            chunk[key] = np.ones((2, 3), np.float32)
        chunk['edge'] = np.zeros(2, np.float32)

        def raw(*args, **kwargs):
            options_seen.append(kwargs)
            return dict(chi2=expected, captured=[chunk])

        engine = types.SimpleNamespace(raw_search=raw)
        with probe.CandidateCapture(engine, [0]) as capture:
            result = engine.raw_search(full=False)
        self.assertIs(result['chi2'], expected)
        self.assertEqual(options_seen, [dict(full=False, capture=True)])
        self.assertIs(engine.raw_search, raw)
        self.assertEqual(set(capture.records), {0, 1})
        self.assertTrue(all(key.startswith('row0_') for key in capture.buffers))

    def test_checkpoint_strict_json_and_no_implicit_gate(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'result.json'
            probe.write(path, dict(value=np.float64(np.nan), scientific_gate_pass=None))
            self.assertEqual(json.loads(path.read_text()), dict(value=None, scientific_gate_pass=None))


if __name__ == '__main__':
    unittest.main()

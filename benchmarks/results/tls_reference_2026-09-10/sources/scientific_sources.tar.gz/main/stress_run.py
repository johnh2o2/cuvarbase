#!/usr/bin/env python3
"""Execute a finite development-only stress suite and retain all outcomes."""
import argparse
import json
from pathlib import Path
import time

import parity_harness as harness
from three_backend import run_case


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--repo-root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    manifest=json.loads(args.manifest.read_text())
    if manifest.get('suite')=='heldout' or args.out.exists():
        parser.error('Only development inputs and a new output directory are allowed')
    args.out.mkdir(parents=True)
    started=time.perf_counter();rows=[]
    for case in manifest['cases']:
        path=args.manifest.parent/case['file']
        if harness.sha(path)!=case['sha256']:raise ValueError('Input hash changed')
        row=run_case(path,args.repo_root,args.out/case['metadata']['name'])
        row.update(name=case['metadata']['name'],metadata=case['metadata'],elapsed_since_start=time.perf_counter()-started)
        rows.append(row)
        harness.write(args.out/'summary.json',dict(cases=rows,planned=len(manifest['cases']),elapsed_seconds=time.perf_counter()-started))
        print(json.dumps({k:v for k,v in row.items() if k!='metadata'}),flush=True)

if __name__=='__main__':main()

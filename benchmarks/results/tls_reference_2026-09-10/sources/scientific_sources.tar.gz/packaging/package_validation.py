#!/usr/bin/env python3
"""Validate receipts and export compact scientific results, without raw inputs."""
import argparse
import csv
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import sys

import numpy as np


def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,data):Path(path).write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
def csv_file(path,rows):
    keys=sorted({k for r in rows for k in r})
    with Path(path).open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=keys);writer.writeheader()
        writer.writerows({k:json.dumps(v) if isinstance(v,(dict,list)) else v for k,v in r.items()} for r in rows)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest',type=Path,required=True)
    parser.add_argument('--seal',type=Path,required=True)
    parser.add_argument('--results',type=Path,required=True)
    parser.add_argument('--harness-root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    sys.path.insert(0,str(args.harness_root.resolve()))
    import parity_harness as h
    manifest=json.loads(args.manifest.read_text());seal=json.loads(args.seal.read_text())
    acceptance=json.loads((args.results/'acceptance.json').read_text())
    if not acceptance['publication_gate']['pass']:raise ValueError('Independent publication gate is not passed')
    if acceptance['inputs_manifest_sha256']!=sha(args.manifest) or acceptance['seal_sha256']!=sha(args.seal):raise ValueError('Acceptance source chain differs')
    if manifest['seal_sha256']!=sha(args.seal):raise ValueError('Manifest/source seal mismatch')
    if args.out.exists():raise ValueError('Refuse to overwrite a public result bundle')
    args.out.mkdir(parents=True)
    digests={};cases=[];comparisons={};retained=0;pruned=0
    for case in manifest['cases']:
        m=case['metadata'];name=m['name'];root=args.results/name
        row={k:m.get(k) for k in ('name','regime','null','latent_white_oracle_snr','ndata','period_count','baseline_days','truth_period','duration_days','fractional_duration','in_transit_observations','observed_events','accepted_proposal','below_approx_native_duration_envelope')}
        row.update(input_sha256=case['sha256'],stellar_radius=m['physical']['radius'],stellar_mass=m['physical']['mass'],
                   impact=m['physical']['impact'],eccentricity=m['physical']['eccentricity'])
        digests[name]={};records={}
        for backend in ('gtls','gtls_corrected','candidate'):
            path=root/backend/'record.json';record=json.loads(path.read_text());records[backend]=record
            if record['input_sha256']!=case['sha256']:raise ValueError('Backend input mismatch')
            if record['seal_sha256']!=sha(args.seal):raise ValueError('Backend seal mismatch')
            if record['harness_sha256']!=seal['source_identity']['harness_sha256']:raise ValueError('Backend harness mismatch')
            if backend=='candidate' and record['engine_sources']!=seal['source_identity']['production_sources']:raise ValueError('Candidate source mismatch')
            entry=dict(record_sha256=sha(path),status=record['status'],arrays=record.get('arrays',{}),
                       arrays_file_sha256=record.get('arrays_sha256'),input_arrays=record.get('input_arrays'),
                       result=record.get('result'),reference_reuse=record.get('reference_reuse'))
            if record['status']=='ok':
                result=record['result']
                if backend!='candidate' and result['package_sources']!=seal['reference_package_sources']:raise ValueError('Native source mismatch')
                array_path=path.parent/record['arrays_file']
                if array_path.exists():
                    if sha(array_path)!=record['arrays_sha256']:raise ValueError('Retained NPZ mismatch')
                    with np.load(array_path,allow_pickle=False) as values:
                        if set(values.files)!=set(record['arrays']):raise ValueError('Array inventory mismatch')
                        for key in values.files:
                            if h.array_hash(values[key])!=record['arrays'][key]['sha256']:raise ValueError('Array hash mismatch')
                    retained+=1
                else:
                    retention=json.loads((root/'retention.json').read_text())
                    target=str(array_path.relative_to(root))
                    if not retention['all_checks_passed'] or not any(x['file']==target and x['sha256']==record['arrays_sha256'] for x in retention['arrays_removed']):raise ValueError('Missing array without valid predeclared retention receipt')
                    pruned+=1
                for key in ('period','score'):
                    row[backend+'_'+key]=result.get(key)
                row[backend+'_native_snr']=result.get('final_fit',{}).get('native_gtls_snr')
                row[backend+'_primary_period_match']=h.plain(abs(result['period']-m['truth_period'])/m['truth_period']*m['baseline_days']<=.5*m['duration_days']) if result.get('period') is not None else False
                row[backend+'_above_SDE8']=result.get('score') is not None and result['score']>8
                row[backend+'_recovered_at_SDE8']=bool(not m['null'] and row[backend+'_primary_period_match'] and row[backend+'_above_SDE8'])
            else:
                entry['error_last_line']=record.get('error','').strip().splitlines()[-1:]
                row[backend+'_error_last_line']=' '.join(entry['error_last_line'])
            row[backend+'_status']=record['status'];digests[name][backend]=entry
        for reference,filename in (('gtls_corrected','compare.json'),('gtls','literal_compare.json')):
            path=root/filename;comp=json.loads(path.read_text())
            for backend,key in ((reference,'reference_record_sha256'),('candidate','candidate_record_sha256')):
                if key in comp and comp[key]!=sha(root/backend/'record.json'):raise ValueError('Comparison source chain mismatch')
            if comp.get('status')=='compared':
                keys=('checks','final_checks','public_checks')
                compact=dict(status=comp['status'],passed=comp['passed'],numeric_passed=comp['numeric_passed'],
                    decisions_passed=comp['decisions_passed'],ranking=comp['ranking'],thresholds=comp['thresholds'],
                    stage_counts=comp['stage_counts'],counts={k:len(comp[k]) for k in keys},
                    failed={k:{n:v for n,v in comp[k].items() if not v['passed']} for k in keys},
                    nonbitwise={k:[n for n,v in comp[k].items() if v.get('bitwise') is False] for k in keys})
            else:compact=comp
            compact['original_comparison_sha256']=sha(path)
            comparisons.setdefault(name,{})[reference]=compact
            row[reference+'_exact_comparison_passed']=comp['passed']
        trace=root/'correction_trace.json'
        if trace.exists():
            receipt=json.loads(trace.read_text());digests[name]['correction_trace']=receipt
            row['corrected_native_reused']=receipt['proved_no_op']
        cases.append(row)
    summary=json.loads((args.results/'summary.json').read_text())
    csv_file(args.out/'cases.csv',cases);csv_file(args.out/'strata.csv',summary['strata'])
    for filename,source in (('input_manifest.json',args.manifest),('seal.json',args.seal),('acceptance.json',args.results/'acceptance.json')):
        shutil.copy2(source,args.out/filename)
    write(args.out/'comparisons.json',comparisons)
    # Complete numerical output identities and compact fit/source receipts.
    with gzip.GzipFile(str(args.out/'array_digests.json.gz'),'wb',mtime=0) as stream:
        stream.write(json.dumps(digests,separators=(',',':'),allow_nan=False).encode())
    write(args.out/'validation.json',dict(input_cases=len(cases),backend_records=sum(len([b for b in ('gtls','gtls_corrected','candidate') if b in d]) for d in digests.values()),
        retained_npz_archives_verified=retained,pruned_archives_with_valid_retention_receipts=pruned,
        source_chain_verified=True,all_retained_array_digests_verified=True,
        packaging_script_sha256=sha(__file__),
        interpretation='Complete independent input/record/source/comparison chain verified; raw NPZ files remain outside the repository.'))
    write(args.out/'files.json',{p.name:dict(sha256=sha(p),bytes=p.stat().st_size) for p in sorted(args.out.iterdir()) if p.is_file()})
    print(json.dumps(dict(output=str(args.out),cases=len(cases),bytes=sum(p.stat().st_size for p in args.out.iterdir() if p.is_file()))))

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Two predeclared development controls: halve the same realized noise."""
import hashlib,json
from pathlib import Path
import numpy as np

root=Path(__file__).resolve().parent
out=root/'inputs'
if out.exists():raise ValueError('Refuse to overwrite controlled inputs')
out.mkdir()
cases=[]
for original in ('dense_long_solar','dense_long_mdwarf'):
    path=root.parent/'validation/development-long-dense'/(original+'.npz')
    with np.load(path,allow_pickle=False) as source:
        data={k:source[k] for k in source.files if k!='metadata'}
        metadata=json.loads(str(source['metadata']))
    data['y']=1-data['signal']+.5*(data['y']-1+data['signal'])
    data['dy']=.5*data['dy']
    metadata=dict(metadata,name=original+'_snr20',cohort='development',
        latent_white_oracle_snr=20.,realized_latent_white_oracle_snr=2*metadata['realized_latent_white_oracle_snr'],
        noise=dict(metadata['noise'],ou_amplitude=.5*metadata['noise']['ou_amplitude']),
        controlled_parent_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        controlled_transform='y20=1-signal+0.5*(y10-1+signal);dy20=0.5*dy10',
        controlled_interpretation='Same physical signal/grid and same Gaussian+OU realization at half amplitude; development control, not independent recovery evidence',
        controlled_generator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),seal_sha256=None)
    target=out/(metadata['name']+'.npz')
    np.savez_compressed(target,**data,metadata=json.dumps(metadata,sort_keys=True))
    cases.append(dict(file=target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest(),metadata=metadata))
(out/'manifest.json').write_text(json.dumps(dict(suite='controlled-development',cases=cases,
    rule='Exactly two predeclared SNR20 controls; no outcome selection or retuning',
    endpoints='Truth-grid rank; selected/fundamental period ratio; baseline phase drift in true transit durations; aliases reported separately'),indent=2)+'\n')

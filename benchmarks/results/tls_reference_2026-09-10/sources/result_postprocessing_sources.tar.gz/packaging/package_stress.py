#!/usr/bin/env python3
"""Validate and summarize every retained selected-grid stress and control."""
import argparse
import csv
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import sys

import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def compact_final_fit(entry, array_hash):
    """Retain identities for oversized diagnostic lists, not duplicate values."""
    result = entry.get('result') or {}
    fit = result.get('final_fit') or {}
    values = fit.get('transit_times')
    if not isinstance(values, list) or len(values) <= 16384:
        return None
    array = np.asarray(values, dtype='<f8')
    identity = dict(
        dtype=str(array.dtype), shape=list(array.shape),
        sha256=array_hash(array),
        original_json_value_sha256=hashlib.sha256(json.dumps(
            values, separators=(',', ':'), allow_nan=False).encode()).hexdigest(),
        representation='Float64 numerical identity; original list values omitted from compact publication')
    entry['result'] = dict(result)
    entry['result']['final_fit'] = dict(fit)
    entry['result']['final_fit'].pop('transit_times')
    entry['result']['final_fit']['transit_times_identity'] = identity
    return identity


def metrics(metadata, result, values):
    selected = result.get('period')
    truth = metadata['truth_period']
    output = dict(selected_period_days=selected, global_SDE=result.get('score'))
    if selected is None:
        return output
    scale = metadata['baseline_days']/truth/metadata['duration_days']
    drift = abs(selected-truth)*scale
    output.update(selected_over_true_period=selected/truth,
                  drift_in_true_durations=drift,
                  fundamental_period_match=bool(drift <= .5))
    aliases = [(ratio, abs(selected-ratio*truth)/ratio*scale)
               for ratio in (.5, 1/3, 2/3, 1.5, 2.)]
    alias, alias_drift = min(aliases, key=lambda item:item[1])
    output.update(alias_ratio=alias if alias_drift <= .5 else None,
                  alias_drift_in_true_durations=alias_drift)
    if values is None:
        output['truth_grid_metrics_available'] = False
        return output
    output['truth_grid_metrics_available'] = True
    periods = values['periods']
    index = int(np.argmin(abs(periods-truth)))
    exact = abs(float(periods[index])-truth) <= 1e-12*truth
    output['truth_is_grid_point'] = exact
    if exact:
        chi2 = np.asarray(values['chi2'])
        mask = np.asarray(values['chi2_mask'], dtype=bool)
        output.update(truth_index=index, truth_masked=bool(mask[index]),
                      truth_final_chi2=float(chi2[index]),
                      truth_final_chi2_rank=(None if mask[index] else
                          1+int(np.count_nonzero((~mask) & (chi2 < chi2[index])))))
        for stage in ('stage0', 'stage1', 'stage2'):
            key = stage+'_chi2'
            if key not in values:
                continue
            stage_values = np.asarray(values[key])
            stage_mask = np.asarray(values[key+'_mask'], dtype=bool)
            output[stage+'_truth_chi2_rank'] = (None if stage_mask[index] else
                1+int(np.count_nonzero((~stage_mask) & (stage_values < stage_values[index]))))
    peak = result.get('global_power_primary_index')
    output['global_power_peak_period_days'] = None if peak is None else float(periods[int(peak)])
    return output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--controls-results', type=Path, required=True)
    parser.add_argument('--controls-collection-index', type=Path,
        help='Original verified checkpoint index: permits explicit collection-loss records for controls only')
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    sys.path.insert(0, str(args.root/'validation'))
    import parity_harness as harness
    if args.out.exists():
        raise ValueError('Use a new stress publication directory')
    development = args.root/'validation/collected-corrected-development/evidence'
    groups = (
        ('selected_grid', args.root/'validation/development-stress/manifest.json',
         development/'validation-corrected-stress-v1'),
        ('long_period', args.root/'validation/development-long-dense/manifest.json',
         development/'validation-corrected-long-v1'),
        ('stronger_controls', args.root/'long-controls/inputs/manifest.json', args.controls_results))
    rows, digests, comparisons, sources, manifests = [], {}, {}, {}, {}
    verified_arrays = 0
    uncollected_arrays = []
    compacted_fields = []
    collection_index = (json.loads(args.controls_collection_index.read_text())
                        if args.controls_collection_index else None)
    for group, manifest_path, result_root in groups:
        manifest = json.loads(manifest_path.read_text())
        manifests[group] = dict(sha256=sha(manifest_path), file=group+'_inputs.json')
        for case in manifest['cases']:
            metadata = case['metadata']
            name = metadata['name']
            if sha(manifest_path.parent/case['file']) != case['sha256']:
                raise ValueError('Stress input differs from its original manifest')
            row = dict(group=group, name=name, input_sha256=case['sha256'],
                       ndata=metadata['ndata'], baseline_days=metadata['baseline_days'],
                       period_count=metadata['period_count'], truth_period_days=metadata['truth_period'],
                       duration_days=metadata['duration_days'],
                       fractional_duration=metadata['duration_days']/metadata['truth_period'],
                       duration_times_ndata=metadata['duration_days']/metadata['truth_period']*metadata['ndata'],
                       white_oracle_snr=metadata['latent_white_oracle_snr'],
                       in_transit_observations=metadata['in_transit_observations'],
                       observed_events=metadata['observed_events'], null=metadata['null'],
                       radius=metadata['physical']['radius'], mass=metadata['physical']['mass'],
                       impact=metadata['physical']['impact'], eccentricity=metadata['physical']['eccentricity'])
            folder = result_root/name
            digests[name] = dict(group=group, input_metadata=metadata, backends={})
            for backend in ('gtls', 'gtls_corrected', 'candidate'):
                path = folder/backend/'record.json'
                record = json.loads(path.read_text())
                if record['input_sha256'] != case['sha256']:
                    raise ValueError('Stress result used another input')
                row[backend+'_status'] = record['status']
                entry = dict(record_sha256=sha(path), **record)
                # Paths are local artifact hints, not public result dependencies.
                entry.pop('error', None)
                if record['status'] != 'ok':
                    message = record.get('error', '').strip().splitlines()
                    row[backend+'_error'] = message[-1] if message else None
                    entry['error_last_line'] = row[backend+'_error']
                else:
                    array_path = path.parent/record['arrays_file']
                    if not array_path.exists():
                        if group != 'stronger_controls' or collection_index is None:
                            raise ValueError('Missing stress output without an explicit original collection index')
                        original = 'completion/results/controls/'+name+'/'+backend+'/record.json'
                        if collection_index.get(original, {}).get('sha256') != sha(path):
                            raise ValueError('Missing control output is not bound to its original checkpoint record')
                        calculated = metrics(metadata, record['result'], None)
                        row.update({backend+'_'+key:value for key,value in calculated.items()})
                        entry['derived_period_selection'] = calculated
                        entry['output_collection_state'] = 'original array identities and comparator survive; NPZ container uncollected'
                        uncollected_arrays.append(dict(name=name, backend=backend,
                            original_record_sha256=sha(path), arrays_file_sha256=record['arrays_sha256']))
                        array_path = None
                    if array_path is not None and sha(array_path) != record['arrays_sha256']:
                        raise ValueError('Stress output archive differs')
                    if array_path is not None:
                        with np.load(array_path, allow_pickle=False) as values:
                            if set(values.files) != set(record['arrays']):
                                raise ValueError('Stress array inventory differs')
                            for key in values.files:
                                identity = record['arrays'][key]
                                if (harness.array_hash(values[key]) != identity['sha256'] or
                                        list(values[key].shape) != identity['shape'] or
                                        str(values[key].dtype) != identity['dtype']):
                                    raise ValueError('Stress numerical array differs: '+key)
                            calculated = metrics(metadata, record['result'], values)
                            row.update({backend+'_'+key:value for key,value in calculated.items()})
                            entry['derived_period_selection'] = calculated
                        verified_arrays += 1
                compacted = compact_final_fit(entry, harness.array_hash)
                if compacted is not None:
                    compacted_fields.append(dict(name=name, backend=backend,
                        field='result.final_fit.transit_times', identity=compacted))
                digests[name]['backends'][backend] = entry
                source = dict(harness_sha256=record['harness_sha256'], engine_sources=record.get('engine_sources'),
                              native_sources=record.get('result', {}).get('package_sources'))
                source_id = hashlib.sha256(json.dumps(source, sort_keys=True).encode()).hexdigest()
                sources[source_id] = source
                entry['source_identity_id'] = source_id
            comparisons[name] = {}
            for backend, filename in (('gtls_corrected','compare.json'), ('gtls','literal_compare.json')):
                path = folder/filename
                result = json.loads(path.read_text())
                if result.get('reference_record_sha256') not in (None, sha(folder/backend/'record.json')):
                    raise ValueError('Stress comparison reference changed')
                if result.get('candidate_record_sha256') not in (None, sha(folder/'candidate/record.json')):
                    raise ValueError('Stress comparison candidate changed')
                row[backend+'_exact_comparison_passed'] = result['passed']
                comparisons[name][backend] = dict(original_sha256=sha(path), **result)
            trace = folder/'correction_trace.json'
            if trace.exists():
                digests[name]['correction_trace'] = json.loads(trace.read_text())
            rows.append(row)
    if len(rows) != 25:
        raise ValueError('Every one of23 original stresses and2 controls must be accounted for')
    args.out.mkdir(parents=True)
    keys = sorted({key for row in rows for key in row})
    with (args.out/'cases.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=keys)
        writer.writeheader()
        writer.writerows(rows)
    for group, path, _ in groups:
        shutil.copyfile(path, args.out/manifests[group]['file'])
    for filename, value in (('array_digests.json.gz', digests), ('comparisons.json.gz', comparisons)):
        with gzip.GzipFile(str(args.out/filename), 'wb', mtime=0) as stream:
            stream.write(json.dumps(value, separators=(',', ':'), allow_nan=False).encode())
    write(args.out/'source_identities.json', sources)
    write(args.out/'validation.json', dict(classification='development numerical stress and fixed-noise controls',
        total_cases=len(rows), backend_records=len(rows)*3,
        input_file_hashes_verified=True, retained_npz_and_all_array_digests_verified=verified_arrays,
        uncollected_retained_outputs=uncollected_arrays,
        compacted_result_fields=compacted_fields,
        controls_collection_index_sha256=(sha(args.controls_collection_index) if args.controls_collection_index else None),
        corrected_pairs=sum(row['gtls_corrected_exact_comparison_passed'] is True for row in rows),
        literal_pairs=sum(row['gtls_exact_comparison_passed'] is True for row in rows),
        exceptions=[dict(name=row['name'], statuses={backend:row[backend+'_status'] for backend in
            ('gtls', 'gtls_corrected', 'candidate')}) for row in rows if row['gtls_corrected_exact_comparison_passed'] is not True],
        inputs=manifests, packaging_source_sha256=sha(__file__),
        limits=['Selected-period grids contain truth and aliases and are not blind recovery trials',
                'No SDE8 acceptance threshold is applied to the two stronger controls',
                'A matched missed signal is numerical parity, not useful sensitivity evidence',
                'Different development source identities remain explicit in each record']))
    write(args.out/'files.json', {path.name:dict(sha256=sha(path), bytes=path.stat().st_size)
                                for path in sorted(args.out.iterdir()) if path.is_file()})
    print(json.dumps(dict(output=str(args.out), cases=len(rows), verified_arrays=verified_arrays)))


if __name__ == '__main__':
    main()

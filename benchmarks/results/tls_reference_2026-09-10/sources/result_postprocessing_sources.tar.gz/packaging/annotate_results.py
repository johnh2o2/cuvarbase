#!/usr/bin/env python3
"""Write readable descriptions from completed compact result tables."""
import argparse
import csv
import json
from pathlib import Path


REGIMES = {
    'tess_solar': 'TESS, ordinary solar',
    'tess_highimpact': 'TESS, high impact solar',
    'tess_eccentric': 'TESS, eccentric solar',
    'tess_mdwarf': 'TESS, 0.1 solar mass/radius',
    'ztf_solar': 'ZTF, ordinary solar',
    'ztf_highimpact': 'ZTF, high impact solar',
    'ztf_mdwarf': 'ZTF, 0.1 solar mass/radius',
    'tess_gap': 'Gapped TESS, ordinary solar',
}
BACKENDS = ('gtls', 'gtls_corrected', 'candidate')


def truth(value):
    return value == 'True'


def rows(path):
    with path.open(newline='') as stream:
        return list(csv.DictReader(stream))


def counts(values, suffix):
    return ' / '.join(str(sum(truth(row[backend+suffix]) for row in values)) for backend in BACKENDS)


def main_readme(root):
    acceptance = json.loads((root/'acceptance.json').read_text())
    if acceptance['publication_gate']['pass'] is not True:
        raise ValueError('Cannot describe an unaccepted confirmation as complete')
    values = rows(root/'cases.csv')
    if len(values) != 160:
        raise ValueError('The full confirmation has160 cases')
    count = acceptance['counts']
    table = ['| Regime | Recovered / 12: native / corrected / cuvarbase | Nulls above 8 / 8: native / corrected / cuvarbase |',
             '| --- | ---: | ---: |']
    for regime, label in REGIMES.items():
        selected = [row for row in values if row['regime'] == regime]
        injected = [row for row in selected if not truth(row['null'])]
        null = [row for row in selected if truth(row['null'])]
        if len(injected) != 12 or len(null) != 8:
            raise ValueError('A predeclared regime is incomplete')
        table.append('| '+label+' | '+counts(injected, '_recovered_at_SDE8')+' | '+counts(null, '_above_SDE8')+' |')
    text = f'''# Independent full-search confirmation

All **{count['numerical_pairs_passed']} of 160** planned inputs passed the exact
corrected-GTLS/cuvarbase numerical and public-result checks. The untouched
GTLS comparison passed on **{count['literal_exact_pairs']} of 160** inputs.
`acceptance.json` records the completed gate, source seal, counts and limits;
`comparisons.json` retains the per-case differences.

Each of eight regimes contains three independent injections at each white-noise
oracle SNR 6, 8, 10 and 12, plus eight independent nulls. The full period arrays
come from the pinned native grid arithmetic at oversampling 3; no true period
was inserted. Both searches received identical arrays with a common positive
time origin and the same search bounds. Separate tests cover automatic-grid
dispatch. The injections use exposure-integrated physical transit signals;
nulls independently draw from the same four latent noise recipes. Their
additional OU noise is excluded from the quoted white-noise oracle SNR.
Recovery is conditional on at least five in-transit observations and two
sampled events; every proposal count is retained in the input manifest.
Passband baselines are assumed already removed. Transit depths and shapes are
achromatic, and both APIs receive only `t`, `y` and `dy`; retained band labels
do not imply a fitted multiband model.

The following outcomes use the predeclared, **uncalibrated SDE threshold 8**.
Recovery additionally requires period drift over the observed baseline to be
no more than half the physical transit duration. These counts are descriptive;
they do not establish a common false-positive rate or useful recovery in every
regime. The order in each cell is untouched GTLS / corrected GTLS / cuvarbase.

'''+ '\n'.join(table)+f'''

`strata.csv` separates all four injection SNR levels and the null mixture in
each regime, retains failures, and supplies exact binomial intervals and
simultaneous discordance bounds. Three injections per SNR and eight nulls per
regime cannot establish a one- or two-percentage-point population margin.
The primary evidence is identical complete numerical searches, supplemented
by these recovery/null cross-checks; a shared miss is not a successful detection.

The corrected reference filters masked/nonfinite candidates before the native
first candidate sort. Native CUDA kernels, templates and scoring formulas are
unchanged. Literal GTLS outcomes remain separate. {count['corrected_reference_reused']}
corrected executions were reused only after a complete trace proved that the
correction was a no-op. All nine differing literal searches selected the same
primary period and made the same strict SDE > 8 decision as the corrected
reference and cuvarbase. Their final power spectra and reported SDE values
differ as well as intermediate arrays; all these differences are preserved.
Fitted native SNRs remained identical in those nine cases.
See the [correction explanation](../../../../docs/GTLS_COMPARISON.md#invalid-candidate-correction).

`array_digests.json.gz` contains every retained numerical-output identity,
dtype, shape, compact fit result, record hash and no-op trace. Full NPZ outputs
were compared before the predeclared retention step. `validation.json`
records verification of the retained archives and explicit receipts for the
matching archives removed after comparison. Large output tensors stay outside
the repository; their complete numerical identities remain in this archive.

The published primary receipts come from a complete reexecution after an
earlier run's result collection failed. All 160 original inputs, seeds, source
hashes, settings, sample counts and gates remained unchanged. Earlier
uncollected output reports are not counted as completed evidence, and repeated
executions are not additional independent samples. The completed main search,
its original acceptance and its on-host compact verification were recovered
from complete members of a truncated final download. Every original record,
comparison and numerical-output digest survived. Of 75 retained NPZ output
archives, 66 were recovered and independently checked; nine were not collected.
Those nine are disclosed collection losses, not predeclared pruning.
The separate 405 matching output archives had already been removed under the
original retention rule. [Collection details](collection.json) preserve the
original acceptance hash, recovery evidence and missing-container identities.

Restore the exact inputs and replay the comparison with the
[maintained tools](../../../tls_reference/README.md). The
[source archive](../sources/README.md) preserves the exact executed scientific
code and distinguishes the original generation environment from the GPU
execution environment. `files.json` hashes the original compact result files.
'''
    (root/'README.md').write_text(text)


def supplement_readme(root):
    acceptance = json.loads((root/'acceptance.json').read_text())
    if acceptance['publication_gate']['pass'] is not True:
        raise ValueError('The supplementary numerical gate is incomplete')
    values = rows(root/'cases.csv')
    if len(values) != 24 or not all(truth(row['null']) for row in values):
        raise ValueError('The supplement must retain all 24 fixed null inputs')
    table = ['| Regime | Native / corrected / cuvarbase nulls above SDE 8 (of 8) |', '| --- | ---: |']
    for regime in ('tess_solar', 'tess_gap', 'ztf_solar'):
        subset = [row for row in values if row['regime'] == regime]
        if len(subset) != 8:
            raise ValueError('A supplementary regime is incomplete')
        table.append('| '+REGIMES[regime]+' | '+counts(subset,'_above_SDE8')+' |')
    count = acceptance['counts']
    (root/'README.md').write_text(f'''# Supplementary null population

All **{count['numerical_pairs_passed']} of 24** separately predeclared null inputs
passed the corrected-GTLS/cuvarbase numerical and public-result comparison.
Untouched GTLS matched on **{count['literal_exact_pairs']} of 24** inputs.
This population has its own unchanged manifest, seal, stream and acceptance
receipt; it is not merged into the main 160-case confirmation counts.

Each regime supplies `null_0008` through `null_0015`. Together with the main
study's eight nulls, these define 16 distinct noise-only inputs per timing
regime. The published timing scope is single-source latency; collecting the
supplement does not establish TLS batch throughput.

'''+ '\n'.join(table)+'''

SDE 8 is descriptive and uncalibrated. `strata.csv` retains each regime's exact
binomial interval, discordance bound and any failures. The methods' numerical
agreement does not imply that this threshold has the same false-positive rate
on different cadences. See the [main confirmation](../validation/README.md)
for the shared numerical endpoints, noise model, correction and limitations.

The original input arrays are in the compact bank. The
[timing reproduction route](../../../tls_reference/timing/README.md#reproduce-the-published-timing-cohort)
restores both populations and preserves their separate provenance through
validation and timing. `array_digests.json.gz` retains complete numerical
identities and the correction/no-op evidence; `validation.json` documents
verification and the original retention rule.

This population ran on a separate RTX A6000 host; the main confirmation used
an A40. Its original acceptance and complete compact results were recovered
unchanged after the subsequent development-control gate stopped the pipeline.
All 72 raw records and 48 comparisons were independently verified. Nine
retained output NPZ containers were not collected; their complete numerical
identities and prior on-host verification survive. The other 63 archives had
already been removed under the original retention rule. These collection
losses and the later control outcome do not alter this separately sealed
24-case gate. [Collection details](collection.json) and
[execution environment](execution_environment.json) keep those scopes explicit.
''')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bundle', type=Path, required=True)
    args = parser.parse_args()
    main_readme(args.bundle/'validation')
    supplement_readme(args.bundle/'supplement')


if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""Authenticate the completed supplemental package after interrupted collection."""
import argparse
import csv
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def package(root, output):
    checkpoint = root / 'completion-checkpoints'
    results = checkpoint / 'files/completion/results'
    raw = results / 'supplement'
    salvage = root / 'completion/salvage_completion01'
    compact = salvage / 'files/completion/results/compact/supplement'
    inventory = read(salvage / 'inventory.json')
    assert sha(root / inventory['source_archive']) == inventory['source_sha256']
    members = {x['file']: x for x in inventory['complete_members']}
    for name, identity in read(compact / 'files.json').items():
        assert sha(compact / name) == identity['sha256']
        assert members['completion/results/compact/supplement/' + name]['sha256'] == identity['sha256']
    manifest, seal = read(compact / 'input_manifest.json'), read(compact / 'seal.json')
    assert sha(compact / 'input_manifest.json') == sha(root / 'validation-supplement/inputs/manifest.json')
    assert sha(compact / 'seal.json') == sha(root / 'validation-supplement/seal.json')
    acceptance = read(raw / 'acceptance.json')
    assert sha(raw / 'acceptance.json') == sha(compact / 'acceptance.json')
    assert acceptance['publication_gate']['pass'] is True
    assert acceptance['source_identity'] == manifest['source_identity'] == seal['source_identity']
    assert acceptance['inputs_manifest_sha256'] == sha(compact / 'input_manifest.json')
    assert acceptance['seal_sha256'] == sha(compact / 'seal.json')
    assert acceptance['reference_package_sources'] == seal['reference_package_sources']
    with gzip.open(compact / 'array_digests.json.gz', 'rt') as stream:
        digests = json.load(stream)
    comparisons = read(compact / 'comparisons.json')
    loss, pruned = [], 0
    file_index = read(checkpoint / 'file-index.json')
    files_verified = {}
    def check(path):
        relative = str(path.relative_to(checkpoint / 'files'))
        identity = file_index[relative]
        assert sha(path) == identity['sha256'] and path.stat().st_size == identity['size']
        files_verified[relative] = identity['sha256']
    for case in manifest['cases']:
        name = case['metadata']['name']; folder = raw / name
        assert case['metadata']['null'] is True
        retention_path = folder / 'retention.json'
        retention = read(retention_path) if retention_path.exists() else None
        if retention is not None:
            check(retention_path)
        records = {}
        for backend in ('gtls', 'gtls_corrected', 'candidate'):
            path = folder / backend / 'record.json'; check(path)
            record = read(path); records[backend] = record
            frozen = digests[name][backend]
            assert sha(path) == frozen['record_sha256']
            assert record['status'] == 'ok' and record['input_sha256'] == case['sha256']
            assert record['harness_sha256'] == seal['source_identity']['harness_sha256']
            assert record['seal_sha256'] == sha(compact / 'seal.json')
            assert record['arrays'] == frozen['arrays'] and record['result'] == frozen['result']
            assert record['options'] == seal['options'] and record['positive_origin'] is True
            assert (record['engine_kind'], record['mode'], record['chunk_policy'], record['auto_grid']) == ('public', 'full', 'default', False)
            if backend == 'candidate':
                assert record['engine_sources'] == seal['source_identity']['production_sources']
            else:
                assert record['result']['package_sources'] == seal['reference_package_sources']
            identity = dict(file=backend + '/' + record['arrays_file'], sha256=record['arrays_sha256'])
            if retention is not None:
                assert retention['all_checks_passed'] is True and identity in retention['arrays_removed']
                pruned += 1
            else:
                loss.append(dict(file=name + '/' + identity['file'], sha256=identity['sha256']))
        assert all(records[b]['input_arrays'] == records['gtls']['input_arrays'] for b in records)
        for backend, filename in (('gtls_corrected', 'compare.json'), ('gtls', 'literal_compare.json')):
            path = folder / filename; check(path); comparison = read(path)
            assert sha(path) == comparisons[name][backend]['original_comparison_sha256']
            assert comparison['reference_record_sha256'] == sha(folder / backend / 'record.json')
            assert comparison['candidate_record_sha256'] == sha(folder / 'candidate/record.json')
            assert comparison['gates'] == seal['gates']
            assert comparison['status'] == 'compared' and comparison['passed'] is True
        trace = folder / 'correction_trace.json'; check(trace)
        assert read(trace) == digests[name]['correction_trace'] and read(trace)['proved_no_op'] is True
    assert len(manifest['cases']) == 24 and len(loss) == 9 and pruned == 63
    assert acceptance['counts'] == dict(planned=24, accounted=24, numerical_pairs_passed=24,
                                        literal_exact_pairs=24, corrected_reference_reused=24)
    assert read(raw / 'progress.json')['status'] == 'complete'
    assert read(raw / 'summary.json')['state'] == read(raw / 'progress.json')
    shutil.copytree(compact, output)
    write(output / 'collection.json', dict(schema_version=1, original_acceptance_unchanged=True,
        original_acceptance_sha256=sha(raw / 'acceptance.json'), complete_original_cases=24,
        complete_original_backend_records=72, complete_original_comparisons=48,
        source_partial_archive_sha256=inventory['source_sha256'], source_partial_archive_bytes=inventory['source_bytes'],
        raw_record_and_comparison_hashes_verified=True, checkpoint_file_index_sha256=sha(checkpoint / 'file-index.json'),
        source_array_digests_sha256=sha(compact / 'array_digests.json.gz'),
        uncollected_retained_npz=loss, original_predeclared_pruning_count=pruned,
        original_on_host_array_verification=read(compact / 'validation.json'), auditor_source_sha256=sha(__file__),
        scope='The original supplemental24-case acceptance and full compact science package survive unchanged. All72 raw records and48 original comparisons were independently checked. Nine retained NPZ containers were not collected; their on-host verification and complete numerical identities survive. Subsequent selected-grid control failure is separate and never changes this original gate.'))
    env = results / 'environment'
    gpu = ET.parse(env / 'gpu.xml').getroot(); device = gpu.find('gpu')
    packages = dict(line.split('==', 1) for line in (env / 'freeze.txt').read_text().splitlines()
                    if '==' in line and not line.startswith('#'))
    write(output / 'execution_environment.json', dict(study='supplement24 and stronger controls',
        python_platform_markers=read(env / 'install.json')['environment'],
        gpu=dict(name=device.findtext('product_name'), driver_version=gpu.findtext('driver_version'),
                 driver_cuda_support=gpu.findtext('cuda_version'), framebuffer_total=device.findtext('fb_memory_usage/total')),
        threads={k: 1 for k in ('NUMBA_NUM_THREADS','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS',
                               'NUMEXPR_NUM_THREADS','VECLIB_MAXIMUM_THREADS','BLIS_NUM_THREADS')},
        packages=packages, source_evidence={n: sha(env / n) for n in ('gpu.xml','cpu.txt','cpu-quota.json','freeze.txt','install.json')},
        scope='This supplemental execution used a separate RTX A6000 host. The main160 study used an A40. These records are scientific validation and contain no accepted headline timing campaign.'))
    print(json.dumps(dict(cases=24, records=72, comparisons=48, retained_containers_uncollected=9,
                          original_acceptance_sha256=sha(output / 'acceptance.json'))))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    package(args.root.resolve(), args.out.resolve())

#!/usr/bin/env python3
"""Recover completed original evidence; never recreate a scientific acceptance."""
import argparse
import csv
import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

import numpy as np


BACKENDS = ('gtls', 'gtls_corrected', 'candidate')


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def array_hash(value):
    value = np.ascontiguousarray(value)
    h = hashlib.sha256()
    h.update(json.dumps(value.dtype.descr if value.dtype.names else value.dtype.str).encode())
    h.update(json.dumps(value.shape).encode())
    h.update(value.tobytes())
    return h.hexdigest()


def audit(root, output):
    salvage = root / 'completion/salvage'
    inventory = read(salvage / 'inventory.json')
    partial = root / inventory['source_archive']
    assert sha(partial) == inventory['source_sha256']
    members = {v['file']: v for v in inventory['complete_members']}
    checkpoint = root / 'recovery-checkpoints'
    index = read(checkpoint / 'file-index.json')
    archives = {v['archive']: v for v in (json.loads(line) for line in
                (checkpoint / 'guard-events.jsonl').read_text().splitlines())
                if v.get('event') == 'snapshot_verified'}
    used_archives = {}
    proven = {}
    output.mkdir(parents=True, exist_ok=False)

    def take(relative, expected=None):
        full = 'rescue/results/main/' + relative
        candidates = [('salvaged_complete_member', salvage / 'files' / full),
                      ('verified_checkpoint', checkpoint / 'files' / full)]
        for kind, source in candidates:
            if not source.is_file():
                continue
            digest = sha(source)
            if expected and digest != expected:
                continue
            if kind == 'salvaged_complete_member':
                assert members[full]['sha256'] == digest
                assert members[full]['bytes'] == source.stat().st_size
                origin = dict(kind=kind, source_archive_sha256=inventory['source_sha256'],
                              member=full, sha256=digest)
            else:
                entry = index[full]
                assert entry['sha256'] == digest and entry['size'] == source.stat().st_size
                archive = Path(entry['archive'])
                if archive.name not in used_archives:
                    a = archives[archive.name]
                    assert sha(archive) == a['archive_sha256']
                    used_archives[archive.name] = a['archive_sha256']
                with tarfile.open(archive) as stream:
                    actual = stream.extractfile(full).read()
                assert hashlib.sha256(actual).hexdigest() == digest
                origin = dict(kind=kind, archive=archive.name,
                              archive_sha256=used_archives[archive.name], member=full,
                              sha256=digest, checkpoint_verified_epoch=entry['verified_epoch'])
            target = output / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            proven[relative] = origin
            return target
        raise ValueError('No valid complete original file: ' + relative)

    compact = salvage / 'files/rescue/results/compact/main'
    compact_index = read(compact / 'files.json')
    for name, identity in compact_index.items():
        assert sha(compact / name) == identity['sha256']
        full = 'rescue/results/compact/main/' + name
        assert members[full]['sha256'] == identity['sha256']
    with gzip.open(compact / 'array_digests.json.gz', 'rt') as stream:
        digests = json.load(stream)
    comparisons = read(compact / 'comparisons.json')
    manifest, seal = read(compact / 'input_manifest.json'), read(compact / 'seal.json')
    assert sha(root / 'validation/confirmation/manifest.json') == sha(compact / 'input_manifest.json')
    assert sha(root / 'validation/confirmation-seal.json') == sha(compact / 'seal.json')
    acceptance_path = take('acceptance.json', compact_index['acceptance.json']['sha256'])
    acceptance = read(acceptance_path)
    assert acceptance['publication_gate']['pass'] is True
    assert acceptance['inputs_manifest_sha256'] == sha(compact / 'input_manifest.json')
    assert acceptance['seal_sha256'] == sha(compact / 'seal.json')
    assert acceptance['source_identity'] == manifest['source_identity'] == seal['source_identity']
    assert acceptance['reference_package_sources'] == seal['reference_package_sources']
    for name in ('progress.json', 'summary.json', 'pipeline_verification.json', 'options.json', 'gates.json'):
        take(name)
    progress, summary = read(output / 'progress.json'), read(output / 'summary.json')
    names = [v['metadata']['name'] for v in manifest['cases']]
    assert progress['status'] == 'complete' and [v['name'] for v in progress['cases']] == names
    assert summary['state'] == progress and len(names) == 160
    assert read(output / 'options.json') == seal['options'] and read(output / 'gates.json') == seal['gates']
    retained, lost, pruned, literal_differences = [], [], [], []
    counts = dict(planned=160, accounted=160, numerical_pairs_passed=0, literal_exact_pairs=0,
                  corrected_reference_reused=0)
    for case in manifest['cases']:
        name = case['metadata']['name']
        retention = None
        if (salvage / 'files/rescue/results/main' / name / 'retention.json').exists() or (
                checkpoint / 'files/rescue/results/main' / name / 'retention.json').exists():
            retention = read(take(name + '/retention.json'))
        records = {}
        for backend in BACKENDS:
            frozen = digests[name][backend]
            path = take(name + '/' + backend + '/record.json', frozen['record_sha256'])
            record = read(path); records[backend] = record
            assert record['status'] == 'ok' and record['input_sha256'] == case['sha256']
            assert record['seal_sha256'] == sha(compact / 'seal.json')
            assert record['harness_sha256'] == seal['source_identity']['harness_sha256']
            assert (record['engine_kind'], record['mode'], record['chunk_policy'], record['auto_grid'],
                    record['positive_origin']) == ('public', 'full', 'default', False, True)
            assert record['options'] == seal['options']
            if backend == 'candidate':
                assert record['engine_sources'] == seal['source_identity']['production_sources']
            else:
                assert record['result']['package_sources'] == seal['reference_package_sources']
            assert record['arrays'] == frozen['arrays'] and record['result'] == frozen['result']
            assert record['input_arrays'] == frozen['input_arrays']
            relative = name + '/' + backend + '/' + record['arrays_file']
            full = 'rescue/results/main/' + relative
            artifact = salvage / 'files' / full
            identity = dict(file=relative, sha256=record['arrays_sha256'])
            if artifact.is_file() and full in members:
                assert sha(artifact) == identity['sha256'] == members[full]['sha256']
                with np.load(artifact, allow_pickle=False) as values:
                    assert set(values.files) == set(record['arrays'])
                    for key in values.files:
                        value, expected = values[key], record['arrays'][key]
                        assert array_hash(value) == expected['sha256']
                        assert str(value.dtype) == expected['dtype'] and list(value.shape) == expected['shape']
                retained.append(identity)
            elif retention is not None:
                original = dict(file=str(Path(backend) / record['arrays_file']), sha256=identity['sha256'])
                assert retention['all_checks_passed'] is True and original in retention['arrays_removed']
                pruned.append(identity)
            else:
                lost.append(identity)
        assert all(records[b]['input_arrays'] == records['gtls']['input_arrays'] for b in BACKENDS)
        for backend, filename in (('gtls_corrected', 'compare.json'), ('gtls', 'literal_compare.json')):
            frozen = comparisons[name][backend]
            comparison = read(take(name + '/' + filename, frozen['original_comparison_sha256']))
            assert comparison['reference_record_sha256'] == sha(output / name / backend / 'record.json')
            assert comparison['candidate_record_sha256'] == sha(output / name / 'candidate/record.json')
            assert comparison['gates'] == seal['gates']
            assert [x['threshold'] for x in comparison['thresholds']] == seal['thresholds']
            assert comparison['status'] == 'compared' and comparison['passed'] == frozen['passed']
            if backend == 'gtls_corrected':
                assert comparison['passed'] is True
                counts['numerical_pairs_passed'] += 1
            elif comparison['passed']:
                counts['literal_exact_pairs'] += 1
            else:
                literal_differences.append(dict(name=name, ranking=comparison['ranking'],
                    thresholds=comparison['thresholds'], decisions_passed=comparison['decisions_passed']))
        trace = read(take(name + '/correction_trace.json'))
        assert trace == digests[name]['correction_trace']
        assert trace['correction'] == 'finite_candidates_before_ranking_v1'
        counts['corrected_reference_reused'] += int(trace['proved_no_op'])
    assert counts == acceptance['counts']
    verification = read(compact / 'validation.json')
    assert len(retained) + len(lost) == verification['retained_npz_archives_verified'] == 75
    assert len(pruned) == verification['pruned_archives_with_valid_retention_receipts'] == 405
    original_verification = read(output / 'pipeline_verification.json')
    assert original_verification['passed'] and original_verification['cases'] == 160
    assert original_verification['acceptance_sha256'] == sha(acceptance_path)
    shutil.copytree(compact, output / '_recovered_compact')
    proof = dict(schema_version=1, verified=True, acceptance_reconstructed=False,
        science_rerun=False, original_acceptance_sha256=sha(acceptance_path), counts=counts,
        original_compact_files_sha256=sha(compact / 'files.json'),
        source_partial_archive_sha256=inventory['source_sha256'],
        source_partial_archive_bytes=inventory['source_bytes'],
        salvaged_complete_members=len(members), checkpoint_archives_verified=used_archives,
        retained_arrays_locally_verified=retained, retained_arrays_uncollected=lost,
        original_predeclared_pruning_receipts=len(pruned),
        original_on_host_array_verification=verification,
        literal_differences=literal_differences,
        collection_scope='All original480 records,320 comparisons,160 traces, complete acceptance/summary and on-host compact verification recovered. Missing retained NPZ containers are collection loss, never treated as predeclared pruning. Recovered local NPZ arrays were independently byte/dtype/shape verified.',
        original_files=proven, auditor_source_sha256=sha(__file__))
    write(output / 'recovery_receipt.json', proof)
    write(output / 'recovery_files.json', {str(p.relative_to(output)): dict(sha256=sha(p), bytes=p.stat().st_size)
        for p in sorted(output.rglob('*')) if p.is_file()})
    print(json.dumps({k: proof[k] for k in ('verified', 'counts', 'original_acceptance_sha256')}, indent=2))
    print(json.dumps(dict(retained_npz_verified=len(retained), uncollected_npz=len(lost), pruned=len(pruned))))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    audit(args.root.resolve(), args.out.resolve())

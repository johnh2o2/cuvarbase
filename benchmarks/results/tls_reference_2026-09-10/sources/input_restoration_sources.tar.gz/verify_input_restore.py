"""Independent byte/dtype/shape check of the published exact-input restoration."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys
import time

import numpy as np

ROOT = Path('/Users/johnhoffman/Documents/cuvarbase-tls-default-20260910')
REPO = Path('/Users/johnhoffman/Documents/cuvarbase')
TOOL = REPO / 'benchmarks/tls_reference/inputs.py'
STUDIES = [
    ('main', ROOT / 'validation/confirmation/manifest.json'),
    ('supplement', ROOT / 'validation-supplement/inputs/manifest.json'),
    ('selected_grid', ROOT / 'validation/development-stress/manifest.json'),
    ('long_period', ROOT / 'validation/development-long-dense/manifest.json'),
    ('stronger_controls', ROOT / 'long-controls/inputs/manifest.json'),
]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def identity(value):
    value = np.ascontiguousarray(value)
    h = hashlib.sha256()
    h.update(json.dumps(value.dtype.descr if value.dtype.names else value.dtype.str).encode())
    h.update(json.dumps(value.shape).encode())
    h.update(value.tobytes())
    return h.hexdigest()


def main():
    started = time.time()
    spec = importlib.util.spec_from_file_location('exact_input_tool', TOOL)
    tool = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tool)
    base = ROOT / 'publication/input-restoration-proof'
    if base.exists():
        raise ValueError('Proof output already exists')
    base.mkdir()
    rows = []
    for label, manifest_path in STUDIES:
        output = base / label
        restoration = tool.restore_bank(ROOT / 'publication/inputs', label, manifest_path, output)
        original = json.loads(manifest_path.read_text())
        replay = json.loads((output / 'manifest.json').read_text())
        assert (output / 'original_manifest.json').read_bytes() == manifest_path.read_bytes()
        assert len(original['cases']) == len(replay['cases'])
        for original_case, replay_case in zip(original['cases'], replay['cases']):
            before_path = manifest_path.parent / original_case['file']
            after_path = output / replay_case['file']
            assert sha(before_path) == original_case['sha256']
            assert replay_case['original_npz_sha256'] == original_case['sha256']
            assert sha(after_path) == replay_case['sha256']
            assert original_case['metadata'] == replay_case['metadata']
            comparisons = {}
            with np.load(before_path, allow_pickle=False) as before, np.load(after_path, allow_pickle=False) as after:
                assert set(before.files) == set(after.files)
                assert json.loads(str(before['metadata'])) == json.loads(str(after['metadata'])) == original_case['metadata']
                for name in sorted(set(before.files) - {'metadata'}):
                    a, b = before[name], after[name]
                    assert a.dtype == b.dtype and a.shape == b.shape
                    # Byte equality checks signed zero and NaN payloads as well
                    # as every finite value; no tolerance or regeneration.
                    assert a.tobytes(order='C') == b.tobytes(order='C')
                    before_identity, after_identity = identity(a), identity(b)
                    assert before_identity == after_identity == replay_case['arrays'][name]
                    if 'arrays' in original_case:
                        assert before_identity == original_case['arrays'][name]
                    comparisons[name] = dict(dtype=a.dtype.str, shape=list(a.shape),
                                             identity=before_identity, bytes_equal=True)
            rows.append(dict(study=label, file=original_case['file'], arrays=comparisons,
                             metadata_equal=True, original_npz_sha256=original_case['sha256'],
                             restored_npz_sha256=replay_case['sha256'],
                             original_array_hashes_present='arrays' in original_case))
        print(json.dumps(restoration), flush=True)
    receipt = dict(schema_version=1, utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   python=platform.python_version(), numpy=np.__version__,
                   restorer_sha256=sha(TOOL), verifier_sha256=sha(__file__),
                   bank_manifest_sha256=sha(ROOT / 'publication/inputs/bank.json'),
                   bank_arrays_sha256=sha(ROOT / 'publication/inputs/arrays.npz'),
                   original_manifests={name: sha(path) for name, path in STUDIES},
                   verified_cases=len(rows), verified_array_uses=sum(len(row['arrays']) for row in rows),
                   all_original_and_restored_arrays_byte_equal=True,
                   all_original_and_restored_metadata_equal=True,
                   npz_containers_byte_equal=sum(row['original_npz_sha256'] == row['restored_npz_sha256'] for row in rows),
                   elapsed_seconds=time.time() - started, cases=rows,
                   interpretation='Exact frozen input restoration; no newly independent simulations or GPU execution')
    target = ROOT / 'publication/input-restoration-proof.json'
    target.write_text(json.dumps(receipt, indent=2, sort_keys=True) + '\n')
    print(json.dumps({key: value for key, value in receipt.items() if key != 'cases'}, indent=2), flush=True)


if __name__ == '__main__':
    main()

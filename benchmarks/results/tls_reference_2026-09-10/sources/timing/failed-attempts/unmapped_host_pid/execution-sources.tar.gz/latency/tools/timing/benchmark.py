#!/usr/bin/env python3
"""Uninstrumented complete-public-call TLS timings with deferred validation.

Persistent workers retain their raw results until the parent has stopped the
clock. Only then are result arrays hashed and released. No numerical routines
are patched in headline graph mode. The optional row-prefix variant is an
explicit attribution experiment, kept separate from competitor selection.
"""
from __future__ import annotations

import argparse
from collections import Counter
import multiprocessing as mp
import os
from pathlib import Path
import threading
import time
import traceback

if __name__ == '__main__':
    for variable in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
                     'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS', 'NUMBA_NUM_THREADS'):
        os.environ[variable] = '1'

if __package__:
    from .common import (BATCH_REPETITIONS, NATIVE_BACKENDS, REGIMES, SINGLE_REPETITIONS, case_identity,
                         environment, fingerprint, initialize_backend, load_cases,
                         public_batch, public_single, sha, write)
    from .cohort import frozen_outputs, select, verify_worker_sources
else:
    from common import (BATCH_REPETITIONS, NATIVE_BACKENDS, REGIMES, SINGLE_REPETITIONS, case_identity,
                        environment, fingerprint, initialize_backend, load_cases,
                        public_batch, public_single, sha, write)
    from cohort import frozen_outputs, select, verify_worker_sources


def process_ids():
    """Record any visible outer/inner namespace IDs for NVML process checks."""
    result = {os.getpid()}
    status = Path('/proc/self/status')
    if status.exists():
        for line in status.read_text().splitlines():
            if line.startswith('NSpid:'):
                result.update(int(value) for value in line.split()[1:])
    return sorted(result)


def worker(connection, config):
    """One serial public-API consumer, with no timed result serialization."""
    try:
        cases = load_cases(config['manifest'], config['regime'], config.get('names'))
        sources = initialize_backend(config['backend'], config['prefix'], config.get('correction_adapter'))
        import cupy as cp
        connection.send(dict(kind='ready', pid=os.getpid(), namespace_pids=process_ids(), sources=sources))
        retained = []
        while True:
            command = connection.recv()
            if command['kind'] == 'close':
                break
            if command['kind'] == 'validate':
                records, errors = [], []
                for index, result in retained:
                    try:
                        records.append(fingerprint(config['backend'], cases[index], result))
                    except Exception:
                        errors.append(dict(case=cases[index]['name'], traceback=traceback.format_exc()))
                retained = []
                connection.send(dict(kind='validation', records=records, errors=errors))
                continue
            if command['kind'] != 'run':
                raise ValueError('Unknown worker command')
            if retained:
                raise RuntimeError('Previous results were not validated before reuse')
            indices = command['indices']
            selected = [cases[index] for index in indices]
            cp.cuda.runtime.deviceSynchronize()
            started = time.perf_counter()
            error = None
            case_failures = []
            try:
                if command['single']:
                    results = [public_single(config['backend'], selected[0])]
                elif config['backend'] in NATIVE_BACKENDS:
                    # Preserve the identity and elapsed time of a failed
                    # public call, then let independent cases finish. A batch
                    # with any failure is never a timing denominator.
                    for index in indices:
                        call_started = time.perf_counter()
                        try:
                            result = public_single(config['backend'], cases[index])
                            cp.cuda.runtime.deviceSynchronize()
                            retained.append((index, result))
                        except Exception:
                            case_failures.append(dict(case=cases[index]['name'],
                                failure_seconds=time.perf_counter()-call_started,
                                traceback=traceback.format_exc()))
                    results = None
                else:
                    results = public_batch(config['backend'], selected)
                cp.cuda.runtime.deviceSynchronize()
                # Keep the raw returned objects alive through the barrier.
                if results is not None:
                    retained = list(zip(indices, results))
            except Exception:
                error = traceback.format_exc()
                try:
                    cp.cuda.runtime.deviceSynchronize()
                except Exception:
                    pass
            ended = time.perf_counter()
            connection.send(dict(kind='complete', pid=os.getpid(), started=started,
                                 ended=ended, api_seconds=ended-started,
                                 completed_cases=len(retained), error=error,
                                 case_failures=case_failures))
    except Exception:
        try:
            connection.send(dict(kind='fatal', pid=os.getpid(), traceback=traceback.format_exc()))
        except Exception:
            pass
    finally:
        connection.close()


def exclusive_gpu_processes(allowed, *, strict=True):
    """Refuse a timed run when another compute process owns this device."""
    import pynvml as nvml
    nvml.nvmlInit()
    try:
        handle = nvml.nvmlDeviceGetHandleByIndex(0)
        observed = sorted({int(process.pid) for process in nvml.nvmlDeviceGetComputeRunningProcesses(handle)})
    finally:
        nvml.nvmlShutdown()
    foreign = sorted(set(observed) - set(allowed))
    if foreign and strict:
        raise RuntimeError('Foreign GPU compute processes prevent exclusive timings: ' + str(foreign))
    return dict(allowed_pids=sorted(allowed), observed_pids=observed,
                foreign_pids=foreign, exclusive=not foreign)


class WorkerPool:
    def __init__(self, config, width, timeout=1800.):
        self.timeout = timeout
        self.names = config['names']
        self.connections, self.processes = [], []
        begin = time.perf_counter()
        context = mp.get_context('spawn')
        try:
            for _ in range(width):
                parent, child = context.Pipe()
                process = context.Process(target=worker, args=(child, config))
                process.start()
                child.close()
                self.connections.append(parent)
                self.processes.append(process)
            self.ready = [self._receive(connection, 'ready') for connection in self.connections]
        except Exception:
            self.close()
            raise
        self.startup_seconds = time.perf_counter() - begin

    def _receive(self, connection, expected):
        if not connection.poll(self.timeout):
            raise TimeoutError('Worker did not finish within the declared timeout')
        result = connection.recv()
        if result.get('kind') != expected:
            raise RuntimeError('Unexpected worker response: ' + repr(result))
        return result

    def measure(self, indices, *, single=False, warmup=False):
        if single and len(self.connections) != 1:
            raise ValueError('Single-source latency uses one persistent worker')
        # Round-robin assignment is fixed; completion order cannot alter inputs.
        assignments = ([indices[:1]] * len(self.connections) if warmup else
                       [indices[i::len(self.connections)] for i in range(len(self.connections))])
        if any(not values for values in assignments):
            raise ValueError('Every worker must receive at least one case')
        allowed_pids = sorted({pid for value in self.ready for pid in value['namespace_pids']})
        exclusive_before = exclusive_gpu_processes(allowed_pids)
        before = time.perf_counter()
        for connection, values in zip(self.connections, assignments):
            connection.send(dict(kind='run', indices=values, single=single))
        completions = [self._receive(connection, 'complete') for connection in self.connections]
        after = time.perf_counter()  # All public returns + CUDA work completed.
        exclusive_after = exclusive_gpu_processes(allowed_pids, strict=False)
        # No hashing, NumPy comparisons or array IPC occurs before this point.
        validation_begin = time.perf_counter()
        for connection in self.connections:
            connection.send(dict(kind='validate'))
        validation = [self._receive(connection, 'validation') for connection in self.connections]
        records = [record for value in validation for record in value['records']]
        errors = ([value['error'] for value in completions if value['error']] +
                  [error for value in completions for error in value['case_failures']] +
                  [error for value in validation for error in value['errors']])
        if not exclusive_after['exclusive']:
            errors.append(dict(reason='Foreign GPU process observed after the measurement',
                               processes=exclusive_after['foreign_pids']))
        expected = sum(len(values) for values in assignments)
        expected_names = [self.names[index] for values in assignments for index in values]
        observed_names = [value['case'] for value in records]
        if Counter(expected_names) != Counter(observed_names):
            errors.append(dict(reason='Post-barrier result membership differs from the assigned inputs',
                               expected=expected_names, observed=observed_names))
        complete = not errors and sum(value['completed_cases'] for value in completions) == expected
        return dict(status='ok' if complete else 'error', elapsed_seconds=after-before,
                    denominator_seconds=after-before if complete else None,
                    validation_seconds=time.perf_counter()-validation_begin,
                    worker_public_calls=completions, errors=errors, outputs=records,
                    assignments=assignments, source_count=expected, warmup=warmup,
                    exclusive_before=exclusive_before, exclusive_after=exclusive_after)

    def close(self):
        for connection in self.connections:
            try:
                connection.send(dict(kind='close'))
            except (BrokenPipeError, EOFError, OSError):
                pass
        for process in self.processes:
            process.join(timeout=5.)
            if process.is_alive():
                process.terminate()
                process.join(timeout=5.)
        for connection in self.connections:
            connection.close()


class Monitor:
    """One-Hz read-only NVML/cgroup telemetry, outside worker API execution."""
    def __init__(self, path):
        self.path = Path(path)
        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._run, daemon=True)

    def _run(self):
        import json
        try:
            import pynvml as nvml
            nvml.nvmlInit()
            handle = nvml.nvmlDeviceGetHandleByIndex(0)
        except Exception as error:
            handle, nvml = None, None
            setup_error = repr(error)
        with self.path.open('w') as output:
            while not self.stop_event.is_set():
                row = dict(monotonic=time.perf_counter(), utc=time.time())
                try:
                    if handle is not None:
                        utilization = nvml.nvmlDeviceGetUtilizationRates(handle)
                        memory = nvml.nvmlDeviceGetMemoryInfo(handle)
                        row.update(gpu_percent=utilization.gpu, memory_percent=utilization.memory,
                                   used_gpu_bytes=memory.used,
                                   power_mw=nvml.nvmlDeviceGetPowerUsage(handle),
                                   sm_clock_mhz=nvml.nvmlDeviceGetClockInfo(handle, nvml.NVML_CLOCK_SM),
                                   temperature_c=nvml.nvmlDeviceGetTemperature(handle, nvml.NVML_TEMPERATURE_GPU))
                        row['compute_processes'] = [dict(pid=int(process.pid),
                            used_gpu_bytes=int(process.usedGpuMemory))
                            for process in nvml.nvmlDeviceGetComputeRunningProcesses(handle)]
                    else:
                        row['nvml_error'] = setup_error
                    for file in ('cpu.stat', 'memory.current'):
                        path = Path('/sys/fs/cgroup') / file
                        if path.exists():
                            row[file] = path.read_text().strip()
                except Exception as error:
                    row['error'] = repr(error)
                output.write(json.dumps(row) + '\n')
                output.flush()
                self.stop_event.wait(1.)
        if nvml is not None:
            nvml.nvmlShutdown()

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *unused):
        self.stop_event.set()
        self.thread.join(timeout=5.)


def consistency(records, reference=None, expected_names=None, expected_repetitions=None,
                field='strict'):
    """All cases and repetitions must pass before a denominator is eligible."""
    baseline = {} if reference is None else dict(reference)
    problems = []
    if not records or (expected_repetitions is not None and len(records) != expected_repetitions):
        problems.append(dict(reason='Missing declared repetitions', actual=len(records),
                             expected=expected_repetitions))
    expected = (Counter(expected_names) if expected_names is not None else
                Counter(reference.keys()) if reference is not None else None)
    for repetition, record in enumerate(records):
        if record['status'] != 'ok':
            problems.append(dict(repetition=repetition, reason='incomplete public result'))
            continue
        observed = Counter(value['case'] for value in record['outputs'])
        if expected is None:
            expected = observed
        if expected != observed or any(count != 1 for count in observed.values()):
            problems.append(dict(repetition=repetition, reason='Result membership changed',
                                 expected=dict(expected), observed=dict(observed)))
        if record.get('source_count', sum(observed.values())) != sum(observed.values()):
            problems.append(dict(repetition=repetition, reason='Source count differs from returned outputs'))
        for output in record['outputs']:
            name, current = output['case'], output[field]
            if name not in baseline:
                if reference is not None:
                    problems.append(dict(case=name, reason='absent from one-worker reference'))
                else:
                    baseline[name] = current
            elif baseline[name] != current:
                problems.append(dict(case=name, repetition=repetition,
                                     reason=field + ' output hashes changed'))
    return dict(eligible=not problems, problems=problems, reference=baseline)


def run(args):
    measurement_scope = getattr(args, 'measurement_scope', 'full')
    if measurement_scope not in ('full', 'single'):
        raise ValueError('Unknown measurement scope')
    if measurement_scope == 'single' and args.pool_widths != [1]:
        raise ValueError('Single-source latency uses exactly one worker per method')
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    # Apply one CPU math thread per worker before fresh spawned imports. This
    # leaves the declared 1/2/4 worker count as the CPU parallelism control.
    for variable in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
                     'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS', 'NUMBA_NUM_THREADS'):
        os.environ[variable] = '1'
    plan = dict(manifest=str(args.manifest.resolve()), manifest_sha256=sha(args.manifest),
                regimes=args.regimes, measurement_scope=measurement_scope,
                single_repetitions=SINGLE_REPETITIONS,
                batch_repetitions=BATCH_REPETITIONS if measurement_scope == 'full' else 0,
                native_pool_widths=args.pool_widths,
                cpu_math_threads_per_worker=1, full=True, return_arrays=True,
                instrumentation='None in public-call runner; only start/end clocks and completion synchronization',
                scope='Public constructor/validation/template cache/full search/final fit; preloaded files and explicit period-grid generation excluded',
                barrier='Every worker API return plus device synchronization before parent stops; result hashes afterward',
                native_extras='Literal GTLS full calls include CPU per-transit SNR and pink-noise diagnostics absent from cuvarbase',
                sources={path.name: sha(path) for path in Path(__file__).parent.glob('*.py')},
                environment=environment(), cases={})
    selections = {regime: select(args.manifest, args.paired_results, regime) for regime in args.regimes}
    plan['cohort_selection'] = selections
    plan['failure_policy'] = ('Preserve every failed original, use deterministic manifest-order paired-success '
        'replacements before timing, report actual batch size if fewer than16. A new runtime failure '
        'invalidates its run/configuration; rerun a complete paired cohort for any later replacement, '
        'never mix different input cohorts or use failed elapsed times as speed denominators.')
    all_cases = {regime: load_cases(args.manifest, regime,
                    [selections[regime]['single_case']] if measurement_scope == 'single'
                    else selections[regime]['selected_cases'])
                 for regime in args.regimes if selections[regime]['single_case'] is not None}
    plan['cases'] = {regime: [case_identity(case) for case in cases] for regime, cases in all_cases.items()}
    plan['frozen_outputs'] = {regime: frozen_outputs(args.paired_results, cases,
        backends=('gtls', 'candidate', 'gtls_corrected') if selections[regime]['correction_timing']['required']
                 else ('gtls', 'candidate'), manifest_path=args.manifest) for regime, cases in all_cases.items()}
    correction_needed = any(selection['correction_timing']['required'] for selection in selections.values())
    if correction_needed and args.correction_adapter is None:
        raise ValueError('An affected selected case requires --correction-adapter for the additional native cross-check')
    plan['correction_adapter'] = (None if args.correction_adapter is None else
                                 dict(path=str(args.correction_adapter.resolve()), sha256=sha(args.correction_adapter)))
    write(output/'plan.json', plan)
    summary = dict(status='running', regimes={})
    write(output/'summary.json', summary)
    with Monitor(output/'monitor.jsonl'):
        for regime, cases in all_cases.items():
            regimes = summary['regimes'][regime] = {}
            configs = [('candidate', 1, 'graph')] + [('gtls', width, 'graph')
                        for width in args.pool_widths if width <= len(cases)]
            if selections[regime]['correction_timing']['required']:
                configs.append(('gtls_corrected', 1, 'graph'))
            if args.row_ab:
                configs.append(('candidate', 1, 'row'))
            native_reference = None
            for backend, width, prefix in configs:
                label = f'{backend}_{prefix}_{width}worker'
                target = output/regime/label
                target.mkdir(parents=True)
                config = dict(manifest=str(args.manifest.resolve()), regime=regime,
                              backend=backend, prefix=prefix,
                              correction_adapter=None if args.correction_adapter is None else str(args.correction_adapter.resolve()),
                              names=[case['name'] for case in cases], measurement_scope=measurement_scope)
                record = dict(config=config, pool_width=width, single=[], batch=[])
                pool = None
                try:
                    pool = WorkerPool(config, width, timeout=args.timeout)
                    for ready in pool.ready:
                        verify_worker_sources(backend, ready['sources'], selections[regime])
                    record.update(pool_startup_seconds=pool.startup_seconds, workers=pool.ready)
                    record['warmup'] = pool.measure([0], warmup=True,
                                                   single=measurement_scope == 'single')
                    if record['warmup']['status'] != 'ok':
                        raise RuntimeError('Warmup did not complete correctly')
                    write(target/'record.json', record)
                    if width == 1 and selections[regime]['single_case'] is not None:
                        single_index = config['names'].index(selections[regime]['single_case'])
                        for _ in range(SINGLE_REPETITIONS):
                            record['single'].append(pool.measure([single_index], single=True))
                            write(target/'record.json', record)
                    # Optional row-prefix A/B is deliberately single-source;
                    # it is not another entrant in strongest-pool selection.
                    if prefix == 'graph' and measurement_scope == 'full':
                        for _ in range(BATCH_REPETITIONS):
                            record['batch'].append(pool.measure(list(range(len(cases)))))
                            write(target/'record.json', record)
                    gate = consistency(record['batch'] or record['single'],
                                       native_reference if backend == 'gtls' else None,
                                       expected_names=(config['names'] if record['batch'] else
                                                       [selections[regime]['single_case']]),
                                       expected_repetitions=(BATCH_REPETITIONS if record['batch'] else
                                                             SINGLE_REPETITIONS))
                    if backend == 'gtls' and width == 1:
                        if gate['eligible'] and len(gate['reference']) == len(cases):
                            native_reference = gate['reference']
                        else:
                            gate['eligible'] = False
                            gate['problems'].append(dict(reason='No stable complete one-worker reference'))
                    elif backend == 'gtls' and native_reference is None:
                        gate['eligible'] = False
                        gate['problems'].append(dict(reason='One-worker baseline missing or unstable'))
                    record['parity'] = gate
                    expected = {name: value['strict'] for name, value in
                                plan['frozen_outputs'][regime][backend].items()}
                    if prefix == 'row':
                        expected = {selections[regime]['single_case']: expected[selections[regime]['single_case']]}
                    record['frozen_output_gate'] = consistency(record['batch'] or record['single'],
                        reference=expected, expected_names=list(expected),
                        expected_repetitions=BATCH_REPETITIONS if record['batch'] else SINGLE_REPETITIONS)
                    if record['single']:
                        single_name = selections[regime]['single_case']
                        reference = ({single_name: gate['reference'][single_name]}
                                     if single_name in gate['reference'] else None)
                        record['single_parity'] = consistency(record['single'], reference=reference,
                            expected_names=[single_name], expected_repetitions=SINGLE_REPETITIONS)
                        record['full_repeatability_gate'] = consistency(record['single'],
                            expected_names=[single_name], expected_repetitions=SINGLE_REPETITIONS,
                            field='full_digest')
                    else:
                        record['single_parity'] = None
                    record['status'] = ('ok' if all(rep['status'] == 'ok'
                        for rep in record['single'] + record['batch']) else 'measurement_failure')
                except Exception:
                    record.update(status='error', error=traceback.format_exc(),
                                  parity=dict(eligible=False, problems=[dict(reason='runner failure')]))
                finally:
                    if pool is not None:
                        pool.close()
                write(target/'record.json', record)
                regimes[label] = dict(status=record['status'], record=str(target.relative_to(output)/'record.json'),
                    parity=record['parity'],
                    single_seconds=[item['denominator_seconds'] for item in record['single']],
                    batch_seconds=[item['denominator_seconds'] for item in record['batch']])
                write(output/'summary.json', summary)
                if measurement_scope == 'single' and (record['status'] != 'ok' or
                        not record['parity']['eligible'] or
                        not record.get('frozen_output_gate', {}).get('eligible') or
                        not record.get('full_repeatability_gate', {}).get('eligible')):
                    summary['status'] = 'error'
                    write(output/'summary.json', summary)
                    raise RuntimeError('Single-source public timing failed its complete-output gate: ' + regime + '/' + label)
    summary['cohort_selection'] = selections
    summary['measurement_scope'] = measurement_scope
    summary['status'] = ('complete' if all(
        selection['single_case'] is not None if measurement_scope == 'single'
        else selection['actual_batch_size'] == 16
        for selection in selections.values()) else 'insufficient_paired_cases')
    write(output/'summary.json', summary)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--paired-results', type=Path, required=True,
                        help='Completed heldout per-case native/candidate records; selection uses API success only')
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--regimes', nargs='+', choices=REGIMES, default=list(REGIMES))
    parser.add_argument('--measurement-scope', choices=('full', 'single'), default='full',
                        help='Single measures five single-source calls only; full also measures three batches and native pools')
    parser.add_argument('--pool-widths', nargs='+', type=int, choices=(1, 2, 4))
    parser.add_argument('--timeout', type=float, default=1800.)
    parser.add_argument('--row-ab', action='store_true', help='Separate five single-source original-row prefix calls')
    parser.add_argument('--correction-adapter', type=Path,
                        help='Frozen corrected_reference.py from the independent study; used only for affected regimes')
    args = parser.parse_args()
    if args.pool_widths is None:
        args.pool_widths = [1] if args.measurement_scope == 'single' else [1, 2, 4]
    if args.measurement_scope == 'single' and args.pool_widths != [1]:
        parser.error('Single-source latency uses exactly one worker per method')
    if args.pool_widths != sorted(set(args.pool_widths)) or args.pool_widths[0] != 1:
        parser.error('Pool widths must be unique, ascending and include the one-worker baseline first')
    run(args)


if __name__ == '__main__':
    main()

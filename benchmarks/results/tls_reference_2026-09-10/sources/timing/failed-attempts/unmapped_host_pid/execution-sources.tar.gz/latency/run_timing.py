#!/usr/bin/env python3
"""Serial single-source protocol; no cloud/resource actions or batch claims."""
from __future__ import annotations
import argparse
from collections import Counter
import math
import os
from pathlib import Path
import signal
import sys
import traceback

from _driver_support import StageRunner, component_problems, read, sha, utc, write, THREAD_VARS

REGIMES = ('tess_solar', 'tess_gap', 'ztf_solar')


def prepare(args):
    sys.path.insert(0, str(args.timing_tools))
    import cohort
    import common
    selections = {regime: cohort.select(args.manifest, args.paired_results, regime)
                  for regime in REGIMES}
    expected = {}
    for regime, selection in selections.items():
        if selection['single_case'] is None:
            raise ValueError('No paired successful single source: ' + regime)
        cases = common.load_cases(args.manifest, regime, [selection['single_case']])
        backends = (('gtls', 'candidate', 'gtls_corrected')
                    if selection['correction_timing']['required'] else ('gtls', 'candidate'))
        expected[regime] = cohort.frozen_outputs(args.paired_results, cases,
            backends=backends, manifest_path=args.manifest)
    result = dict(measurement_scope='single', created_utc=utc(), manifest_sha256=sha(args.manifest),
        selections=selections, frozen_outputs=expected, single_repetitions=5,
        component_repetitions=5, batch_repetitions=0, native_workers=1,
        requested_single='Original null0000; existing deterministic paired-API-success fallback',
        correction_rule='Conservatively retain the existing entire supporting16-source-cohort trigger; execute only the selected single source',
        cost_forecast_usd=[.14, .24], planned_total_reserve_usd=.27,
        scope='Single-source full API latency plus separate common-search components; no TLS batch throughput or strongest-pool claim',
        sources={str(path.relative_to(args.root)): sha(path) for path in
                 sorted(args.timing_tools.glob('*.py')) + [Path(__file__).resolve(),
                 Path(__file__).with_name('_driver_support.py'), args.timing_tools.parent/'analyze_timing.py']})
    write(args.output/'prepared.json', result)
    return result


def commands(args, corrected):
    tools = args.timing_tools
    shared = ['--manifest', str(args.manifest), '--paired-results', str(args.paired_results),
              '--measurement-scope', 'single']
    adapter = args.root/'validation/corrected_reference.py'
    result = [dict(name='public', timeout_seconds=900, command=[sys.executable,
        str(tools/'benchmark.py'), *shared, '--output', str(args.output/'public'),
        '--pool-widths', '1', '--timeout', '180', '--correction-adapter', str(adapter)])]
    for backend, regimes in (('candidate', REGIMES), ('gtls', REGIMES), ('gtls_corrected', corrected)):
        if not regimes:
            continue
        command = [sys.executable, str(tools/'components.py'), *shared, '--backend', backend,
                   '--output', str(args.output/'components'/backend), '--regimes', *regimes]
        if backend == 'gtls_corrected':
            command += ['--correction-adapter', str(adapter)]
        result.append(dict(name='components_'+backend, timeout_seconds=600, command=command))
    command = [sys.executable, str(tools/'summarize.py'), str(args.output/'public'),
        '--components-gtls', str(args.output/'components/gtls'),
        '--components-candidate', str(args.output/'components/candidate'),
        '--output', str(args.output/'summary.json')]
    if corrected:
        command += ['--components-corrected', str(args.output/'components/gtls_corrected')]
    result.append(dict(name='summarize', timeout_seconds=120, command=command))
    result.append(dict(name='normalize', timeout_seconds=120, command=[sys.executable,
        str(tools.parent/'analyze_timing.py'), '--checks', str(args.output/'summary.json'),
        '--manifest', str(args.manifest), '--acceptance', str(args.paired_results/'acceptance.json'),
        '--output', str(args.output/'timing_analysis.json')]))
    return result


def audit(args, prepared):
    sys.path.insert(0, str(args.timing_tools))
    from benchmark import consistency
    plan = read(args.output/'public/plan.json')
    summary = read(args.output/'summary.json')
    normalized = read(args.output/'timing_analysis.json')
    problems, details = [], {}
    if (plan.get('measurement_scope') != 'single' or plan.get('single_repetitions') != 5 or
            plan.get('batch_repetitions') != 0 or plan.get('native_pool_widths') != [1] or
            plan.get('regimes') != list(REGIMES) or
            plan.get('manifest_sha256') != prepared['manifest_sha256'] or
            plan.get('cohort_selection') != prepared['selections'] or
            plan.get('frozen_outputs') != prepared['frozen_outputs']):
        problems.append('Public plan differs from frozen single-source declaration')
    for regime, selection in prepared['selections'].items():
        name = selection['single_case']
        backends = ['candidate', 'gtls']
        if selection['correction_timing']['required']:
            backends.append('gtls_corrected')
        for backend in backends:
            record = read(args.output/'public'/regime/(backend+'_graph_1worker')/'record.json')
            expected = {name: prepared['frozen_outputs'][regime][backend][name]['strict']}
            checked = consistency(record.get('single', []), reference=expected,
                                  expected_names=[name], expected_repetitions=5)
            full_checked = consistency(record.get('single', []), field='full_digest',
                                       expected_names=[name], expected_repetitions=5)
            if (record.get('status') != 'ok' or record.get('pool_width') != 1 or
                    record.get('batch') or len(record.get('single', [])) != 5 or
                    record.get('warmup', {}).get('status') != 'ok' or
                    not record.get('frozen_output_gate', {}).get('eligible') or
                    not record.get('single_parity', {}).get('eligible') or
                    not checked['eligible'] or not full_checked['eligible']):
                problems.append(regime+'/'+backend+': incomplete or changed public result')
            for rep in record.get('single', []):
                elapsed = rep.get('denominator_seconds')
                if (rep.get('status') != 'ok' or rep.get('errors') or rep.get('source_count') != 1 or
                        not isinstance(elapsed, (int, float)) or not math.isfinite(elapsed) or elapsed <= 0 or
                        Counter(value['case'] for value in rep.get('outputs', [])) != Counter([name]) or
                        not rep.get('exclusive_before', {}).get('exclusive') or
                        not rep.get('exclusive_after', {}).get('exclusive')):
                    problems.append(regime+'/'+backend+': incomplete or nonexclusive repetition')
            component = read(args.output/'components'/backend/(regime+'.json'))
            problems.extend(regime+'/'+backend+': '+item for item in component_problems(component, name))
        result = summary.get('regimes', {}).get(regime, {})
        if (result.get('public_single', {}).get('eligible') is not True or
                result.get('common_search_components', {}).get('eligible') is not True or
                result.get('public_batch', {}).get('status') != 'not_measured'):
            problems.append(regime+': audited single/component gate failed or batch implied')
        if selection['correction_timing']['required']:
            if ((result.get('corrected_native_crosscheck') or {}).get('single', {}).get('eligible') is not True or
                    result.get('corrected_common_search_components', {}).get('eligible') is not True):
                problems.append(regime+': corrected-native comparison gate failed')
        details[regime] = dict(single_case=name, single_replaced=selection['single_replaced'],
            supporting_cohort_size=selection['actual_batch_size'], measured_sources_per_call=1,
            corrected_native_required=selection['correction_timing']['required'])
    rows = normalized.get('timings', [])
    if (normalized.get('measurement_scope') != 'single' or
            normalized.get('verification', {}).get('complete') is not True or len(rows) != 6 or
            any(row.get('mode') != 'single' or row.get('n') != 1 or row.get('workers') != 1 or
                row.get('repetitions') != 5 for row in rows)):
        problems.append('Normalized figure data contains missing singles or unmeasured throughput')
    result = dict(status='accepted' if not problems else 'rejected', measurement_scope='single',
        publication_gate={'pass': not problems, 'problems': problems}, regimes=details,
        created_utc=utc(), manifest_sha256=prepared['manifest_sha256'],
        summary_sha256=sha(args.output/'summary.json'),
        timing_analysis_sha256=sha(args.output/'timing_analysis.json'),
        failed_times_are_speed_denominators=False, batch_throughput_measured=False,
        strongest_pool_comparison_measured=False)
    write(args.output/'acceptance.json', result)
    if problems:
        raise ValueError('Latency acceptance failed: '+repr(problems))
    return result


def run(args):
    args.output.mkdir(parents=True, exist_ok=False)
    terminal = dict(status='running', exit_code=None, measurement_scope='single', started_utc=utc())
    write(args.output/'terminal.json', terminal)
    runner = StageRunner(args)
    code = 2
    try:
        prepared = prepare(args)
        corrected = [name for name, value in prepared['selections'].items()
                     if value['correction_timing']['required']]
        stages = commands(args, corrected)
        write(args.output/'pipeline-plan.json', dict(stages=stages, corrected_regimes=corrected,
            measurement_scope='single', driver_sha256=sha(__file__),
            note='Timeouts are failure limits; the external total-spend guard remains authoritative'))
        for stage in stages:
            runner.run(stage['name'], stage['command'], stage['timeout_seconds'])
            if stage['name'].startswith('components_'):
                backend = stage['name'][len('components_'):]
                for regime in corrected if backend == 'gtls_corrected' else REGIMES:
                    record = read(args.output/'components'/backend/(regime+'.json'))
                    failures = component_problems(record, prepared['selections'][regime]['single_case'])
                    if failures:
                        raise ValueError('Component gate failed: '+regime+'/'+backend+repr(failures))
        audit(args, prepared)
        runner.save('complete')
        terminal.update(status='complete', acceptance='acceptance.json',
            acceptance_sha256=sha(args.output/'acceptance.json'),
            timing_analysis_sha256=sha(args.output/'timing_analysis.json'))
        code = 0
    except BaseException:
        runner.stop_active()
        runner.save('error')
        terminal.update(status='error', error=traceback.format_exc())
        if not (args.output/'acceptance.json').exists():
            write(args.output/'acceptance.json', dict(status='incomplete', measurement_scope='single',
                publication_gate={'pass': False, 'problems': ['A required stage failed or is incomplete']},
                error=terminal['error']))
    finally:
        terminal.update(exit_code=code, ended_utc=utc())
        write(args.output/'terminal.json', terminal)
    return code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('root', 'manifest', 'paired-results', 'output'):
        parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--timing-tools', type=Path)
    args = parser.parse_args()
    for name in ('root', 'manifest', 'paired_results', 'output'):
        setattr(args, name, getattr(args, name).resolve())
    args.timing_tools = (args.timing_tools or args.root/'latency/tools/timing').resolve()
    for name in THREAD_VARS:
        os.environ[name] = '1'
    def interrupted(signum, _):
        raise InterruptedError('Latency runner received signal '+str(signum))
    signal.signal(signal.SIGTERM, interrupted)
    return run(args)


if __name__ == '__main__':
    raise SystemExit(main())

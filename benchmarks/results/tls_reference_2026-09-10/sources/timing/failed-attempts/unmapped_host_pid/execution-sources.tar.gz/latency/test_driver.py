"""CPU-only checks of the private latency completion marker."""
import copy
from pathlib import Path
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest
import run_timing as driver


def fixture(folder, corrected=False):
    root = Path(folder)
    args = SimpleNamespace(root=root, output=root/'out', manifest=root/'manifest.json',
        paired_results=root/'main', timing_tools=Path(__file__).parent/'tools/timing')
    selections, expected, summaries = {}, {}, {}
    rows = []
    for regime in driver.REGIMES:
        name = regime+'_null_0000.npz'
        selections[regime] = dict(single_case=name, single_replaced=False, actual_batch_size=16,
            correction_timing=dict(required=corrected))
        expected[regime] = {}
        backends = ['candidate', 'gtls']+(['gtls_corrected'] if corrected else [])
        for backend in backends:
            strict = dict(periods='exact')
            expected[regime][backend] = {name: dict(strict=strict)}
            rep = dict(status='ok', errors=[], denominator_seconds=1., source_count=1,
                outputs=[dict(case=name, strict=strict, full_digest='full')],
                exclusive_before=dict(exclusive=True), exclusive_after=dict(exclusive=True))
            record = dict(status='ok', pool_width=1, batch=[], single=[copy.deepcopy(rep) for _ in range(5)],
                warmup=dict(status='ok'), frozen_output_gate=dict(eligible=True), single_parity=dict(eligible=True))
            driver.write(args.output/'public'/regime/(backend+'_graph_1worker')/'record.json', record)
            crep = dict(denominator_eligible=True, endpoint_valid=True, output_identical_to_literal=True,
                outputs=dict(full_digest='same'), exclusive_before=dict(exclusive=True),
                exclusive_after=dict(exclusive=True))
            component = dict(status='ok', case=dict(name=name), literal_matches_frozen=True,
                literal_outputs=dict(full_digest='same'), repetitions=[copy.deepcopy(crep) for _ in range(5)])
            driver.write(args.output/'components'/backend/(regime+'.json'), component)
        summaries[regime] = dict(public_single=dict(eligible=True),
            public_batch=dict(status='not_measured'), common_search_components=dict(eligible=True))
        if corrected:
            summaries[regime].update(corrected_native_crosscheck=dict(single=dict(eligible=True)),
                corrected_common_search_components=dict(eligible=True))
        rows.extend([dict(mode='single', n=1, workers=1, repetitions=5) for _ in range(2)])
    prepared = dict(manifest_sha256='manifest', selections=selections, frozen_outputs=expected)
    driver.write(args.output/'public/plan.json', dict(measurement_scope='single', single_repetitions=5,
        batch_repetitions=0, native_pool_widths=[1], regimes=list(driver.REGIMES),
        manifest_sha256='manifest', cohort_selection=selections, frozen_outputs=expected))
    driver.write(args.output/'summary.json', dict(regimes=summaries))
    driver.write(args.output/'timing_analysis.json', dict(measurement_scope='single',
        verification=dict(complete=True), timings=rows))
    return args, prepared


class DriverChecks(unittest.TestCase):
    def test_complete_single_protocol(self):
        for corrected in (False, True):
            with TemporaryDirectory() as folder:
                args, prepared = fixture(folder, corrected)
                self.assertTrue(driver.audit(args, prepared)['publication_gate']['pass'])

    def test_corrupt_or_incomplete_public_receipts_fail_closed(self):
        for change in ('missing', 'batch', 'foreign', 'hash', 'count', 'failed_time'):
            with TemporaryDirectory() as folder:
                args, prepared = fixture(folder)
                path = args.output/'public/tess_solar/gtls_graph_1worker/record.json'
                record = driver.read(path)
                if change == 'missing': record['single'].pop()
                elif change == 'batch': record['batch'] = [{}]
                elif change == 'foreign': record['single'][0]['exclusive_after']['exclusive'] = False
                elif change == 'hash': record['single'][0]['outputs'][0]['strict'] = dict(periods='changed')
                elif change == 'count': record['single'][0]['source_count'] = 16
                else: record['single'][0]['denominator_seconds'] = None
                driver.write(path, record)
                with self.assertRaises(ValueError): driver.audit(args, prepared)
                self.assertFalse(driver.read(args.output/'acceptance.json')['publication_gate']['pass'])

    def test_unmeasured_batch_cannot_enter_figure(self):
        with TemporaryDirectory() as folder:
            args, prepared = fixture(folder)
            path = args.output/'timing_analysis.json'
            value = driver.read(path); value['timings'][0]['mode'] = 'batch'
            driver.write(path, value)
            with self.assertRaises(ValueError): driver.audit(args, prepared)

    def test_required_correction_cannot_be_omitted(self):
        with TemporaryDirectory() as folder:
            args, prepared = fixture(folder, True)
            path = args.output/'summary.json';value = driver.read(path)
            value['regimes']['ztf_solar']['corrected_common_search_components']['eligible'] = False
            driver.write(path, value)
            with self.assertRaises(ValueError): driver.audit(args, prepared)

    def test_absent_scientific_inputs_produce_failure_marker_without_gpu(self):
        with TemporaryDirectory() as folder:
            root = Path(folder)
            args = SimpleNamespace(root=root, output=root/'out', manifest=root/'absent.json',
                paired_results=root/'main', timing_tools=Path(__file__).parent/'tools/timing')
            self.assertEqual(driver.run(args), 2)
            result = driver.read(args.output/'terminal.json')
            self.assertEqual((result['status'], result['exit_code']), ('error', 2))
            self.assertFalse(driver.read(args.output/'acceptance.json')['publication_gate']['pass'])

    def test_commands_never_launch_batches_or_multiple_workers(self):
        args = SimpleNamespace(root=Path('/workspace/tls-default'),
            manifest=Path('/workspace/tls-default/rescue/results/timing_manifest.json'),
            paired_results=Path('/workspace/tls-default/rescue/results/main'),
            output=Path('/workspace/tls-default/latency/results/timing'),
            timing_tools=Path('/workspace/tls-default/latency/tools/timing'))
        stages = driver.commands(args, ['ztf_solar'])
        public = stages[0]['command']
        self.assertEqual(public[public.index('--pool-widths')+1], '1')
        self.assertEqual(public[public.index('--measurement-scope')+1], 'single')
        self.assertNotIn('--row-ab', public)
        self.assertIn('components_gtls_corrected', [stage['name'] for stage in stages])


if __name__ == '__main__':
    unittest.main()

#!/usr/bin/env python3
"""Run the already-declared TLS timing protocol after independent acceptance.

This file creates no cloud resources. Every subprocess is serial, checkpointed,
and confined to the requested evidence directory. The outer rental guard owns
the dollar/deadline limit. Failed or incomplete stages never produce acceptance.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback


REGIMES = ("tess_solar", "tess_gap", "ztf_solar")
THREAD_VARS = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
               "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS", "NUMBA_NUM_THREADS")


def utc():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def timing_tools(args):
    path = (args.timing_tools or args.root / "timing").resolve()
    for name in ("benchmark.py", "common.py", "cohort.py", "components.py", "summarize.py"):
        if not (path / name).is_file():
            raise FileNotFoundError("Required reviewed timing tool is absent: " + str(path / name))
    return path


def imports(args):
    # Timing modules intentionally have no CUDA imports until a worker starts.
    sys.path.insert(0, str(timing_tools(args)))
    import benchmark
    import cohort
    import common
    import summarize
    return benchmark, cohort, common, summarize


def prepare(args):
    """Validate both independent study chains and freeze timing eligibility."""
    _, cohort, common, _ = imports(args)
    selections = {regime: cohort.select(args.manifest, args.paired_results, regime)
                  for regime in REGIMES}
    expected = {}
    for regime, selection in selections.items():
        if not selection["selected_cases"] or selection["single_case"] is None:
            raise ValueError("No paired timing cohort for " + regime)
        cases = common.load_cases(args.manifest, regime, selection["selected_cases"])
        backends = (("gtls", "candidate", "gtls_corrected")
                    if selection["correction_timing"]["required"] else ("gtls", "candidate"))
        expected[regime] = cohort.frozen_outputs(args.paired_results, cases,
            backends=backends, manifest_path=args.manifest)
    adapter = args.root / "validation/corrected_reference.py"
    if any(item["correction_timing"]["required"] for item in selections.values()):
        if not adapter.is_file():
            raise FileNotFoundError("Affected cohort requires the frozen correction adapter")
    result = dict(created_utc=utc(), manifest=str(args.manifest),
        manifest_sha256=sha(args.manifest), selections=selections,
        frozen_outputs=expected,
        correction_adapter=dict(path=str(adapter), sha256=sha(adapter)) if adapter.exists() else None,
        timing_sources={path.name: sha(path) for path in timing_tools(args).glob("*.py")},
        required_single_repetitions=5, required_batch_repetitions=3,
        native_pool_widths=[1, 2, 4], optional_row_prefix_ab=False,
        row_ab_omission="Optional attribution experiment omitted before execution for budget efficiency",
        scope="All full public calls plus separate common-search components; no changes to frozen scientific algorithms")
    write(args.output / "prepared.json", result)
    return result


def preflight(args):
    """Short real-API/process/hash check; these times are never denominators."""
    benchmark, cohort, _, _ = imports(args)
    prepared = read(args.output / "prepared.json")
    regime = REGIMES[0]
    selection = prepared["selections"][regime]
    names = selection["selected_cases"]
    indices = list(range(min(4, len(names))))
    tested_names = [names[index] for index in indices]
    result = dict(status="running", regime=regime, names=tested_names,
                  scope="Untimed eligibility preflight; no headline denominator", configurations={})
    write(args.output / "preflight.json", result)
    configs = [("candidate", 1)] + [("gtls", n) for n in (1, 2, 4) if n <= len(indices)]
    for backend, width in configs:
        config = dict(manifest=str(args.manifest), regime=regime, backend=backend,
                      prefix="graph", correction_adapter=None, names=names)
        pool = None
        record = {}
        label = f"{backend}_{width}worker"
        try:
            pool = benchmark.WorkerPool(config, width, timeout=180.)
            for ready in pool.ready:
                cohort.verify_worker_sources(backend, ready["sources"], selection)
            record["workers"] = pool.ready
            record["warmup"] = pool.measure([indices[0]], warmup=True)
            if record["warmup"]["status"] != "ok":
                raise RuntimeError("Preflight warmup failed: " + label)
            record["run"] = pool.measure(indices)
            expected = {name: prepared["frozen_outputs"][regime][backend][name]["strict"]
                        for name in tested_names}
            record["output_gate"] = benchmark.consistency([record["run"]], reference=expected,
                expected_names=tested_names, expected_repetitions=1)
            if record["run"]["status"] != "ok":
                raise RuntimeError("Preflight public API or exclusive-process gate failed: " + label)
            # A native parallel pool may change native memory-dependent chunk
            # coverage. It is then excluded from selection, never silently
            # compared with candidate. The one-worker and candidate gates must
            # match the study before any longer benchmark is allowed.
            if (backend == "candidate" or width == 1) and not record["output_gate"]["eligible"]:
                raise RuntimeError("Preflight differs from frozen study output: " + label)
            record["status"] = "ok"
        except BaseException:
            record.update(status="error", error=traceback.format_exc())
            raise
        finally:
            if pool is not None:
                pool.close()
            result["configurations"][label] = record
            write(args.output / "preflight.json", result)
    result["status"] = "complete"
    write(args.output / "preflight.json", result)


def component_problems(record, expected_name):
    problems = []
    if record.get("status") != "ok" or record.get("case", {}).get("name") != expected_name:
        problems.append("Missing, failed, or different component case")
    if not record.get("literal_matches_frozen"):
        problems.append("Literal component baseline does not match its own frozen output")
    reps = record.get("repetitions", [])
    if len(reps) != 5:
        problems.append("Component repetition count is not five")
    literal = record.get("literal_outputs", {}).get("full_digest")
    for rep in reps:
        if (not rep.get("denominator_eligible") or not rep.get("endpoint_valid") or
                not rep.get("output_identical_to_literal") or not literal or
                rep.get("outputs", {}).get("full_digest") != literal or
                not rep.get("exclusive_before", {}).get("exclusive") or
                not rep.get("exclusive_after", {}).get("exclusive")):
            problems.append("Invalid component endpoint, output, or exclusive-process gate")
    return problems


def check_components(args, backend, regimes):
    prepared = read(args.output / "prepared.json")
    output = args.output / "components" / backend
    summary = read(output / "summary.json")
    if summary.get("status") != "complete" or summary.get("backend") != backend:
        raise ValueError("Component stage is not complete: " + backend)
    failures = {}
    for regime in regimes:
        path = output / (regime + ".json")
        problems = (component_problems(read(path), prepared["selections"][regime]["single_case"])
                    if path.exists() else ["Missing component record"])
        if problems:
            failures[regime] = problems
    if failures:
        raise ValueError("Component output gate failed: " + json.dumps(failures))


def measured_configuration_problems(record, names, single_name, width):
    """Do not mistake a runner's terminal JSON for completed measurements."""
    problems = []
    if record.get("status") != "ok":
        problems.append("Configuration did not complete successfully")
    if record.get("warmup", {}).get("status") != "ok":
        problems.append("Warmup did not complete")
    if len(record.get("batch", [])) != 3:
        problems.append("Batch repetition count is not three")
    required_singles = 5 if width == 1 and single_name is not None else 0
    if len(record.get("single", [])) != required_singles:
        problems.append("Single repetition count differs from declaration")
    for kind in ("single", "batch"):
        expected = Counter([single_name] if kind == "single" else names)
        for rep in record.get(kind, []):
            elapsed = rep.get("denominator_seconds")
            if (rep.get("status") != "ok" or rep.get("errors") or
                    not isinstance(elapsed, (float, int)) or not math.isfinite(elapsed) or elapsed <= 0 or
                    rep.get("source_count") != sum(expected.values()) or
                    Counter(item["case"] for item in rep.get("outputs", [])) != expected or
                    not rep.get("exclusive_before", {}).get("exclusive") or
                    not rep.get("exclusive_after", {}).get("exclusive")):
                problems.append("Incomplete, failed, mismatched, or nonexclusive measurement")
    return problems


def audit(args):
    prepared = read(args.output / "prepared.json")
    plan = read(args.output / "public/plan.json")
    summary = read(args.output / "summary.json")
    problems, details = [], {}
    if (plan.get("manifest_sha256") != prepared["manifest_sha256"] or
            plan.get("regimes") != list(REGIMES) or plan.get("single_repetitions") != 5 or
            plan.get("batch_repetitions") != 3 or plan.get("native_pool_widths") != [1, 2, 4]):
        problems.append("Public timing plan differs from the declared manifest or repetitions")
    if plan.get("cohort_selection") != prepared["selections"]:
        problems.append("Cohort or acceptance chain changed after preflight")
    if plan.get("frozen_outputs") != prepared["frozen_outputs"]:
        problems.append("Expected output fingerprints changed after preflight")
    for regime, selection in prepared["selections"].items():
        names = selection["selected_cases"]
        n = selection["actual_batch_size"]
        required = [("candidate", 1)] + [("gtls", width) for width in (1, 2, 4) if width <= n]
        if selection["correction_timing"]["required"]:
            required.append(("gtls_corrected", 1))
        regime_problems = []
        if not 0 < n <= 16 or n != len(names) or selection["single_case"] not in names:
            regime_problems.append("Invalid actual cohort size or single case")
        for backend, width in required:
            label = f"{backend}_graph_{width}worker"
            path = args.output / "public" / regime / label / "record.json"
            items = (measured_configuration_problems(read(path), names, selection["single_case"], width)
                     if path.exists() else ["Missing required configuration"])
            regime_problems.extend(label + ": " + item for item in items)
        value = summary.get("regimes", {}).get(regime, {})
        for field in ("public_single", "public_batch", "common_search_components"):
            if value.get(field, {}).get("eligible") is not True:
                regime_problems.append("Required audited output gate failed: " + field)
        if value.get("public_batch", {}).get("source_count") != n:
            regime_problems.append("Audited batch denominator uses the wrong source count")
        if selection["correction_timing"]["required"]:
            corrected = value.get("corrected_native_crosscheck") or {}
            for kind in ("single", "batch"):
                if corrected.get(kind, {}).get("eligible") is not True:
                    regime_problems.append("Corrected-native public gate failed: " + kind)
            if value.get("corrected_common_search_components", {}).get("eligible") is not True:
                regime_problems.append("Corrected-native common-search gate failed")
        problems.extend(regime + ": " + item for item in regime_problems)
        pools = value.get("public_batch", {}).get("native_pool_configurations", {})
        details[regime] = dict(actual_batch_size=n, requested_batch_size=16,
            single_case=selection["single_case"], single_replaced=selection["single_replaced"],
            excluded_originals=selection["excluded_cases"],
            corrected_native_timing_required=selection["correction_timing"]["required"],
            strongest_tested_native_workers=value.get("public_batch", {}).get("strongest_tested_native_workers"),
            pool_eligibility={width: dict(eligible=row["eligible"],
                output_problems=row["output_gate"]["problems"]) for width, row in pools.items()},
            problems=regime_problems)
    result = dict(status="accepted" if not problems else "rejected", publication_gate={"pass": not problems, "problems": problems}, created_utc=utc(), regimes=details,
        manifest_sha256=prepared["manifest_sha256"], summary_sha256=sha(args.output / "summary.json"),
        public_plan_sha256=sha(args.output / "public/plan.json"),
        scope="Complete public timings and separate common-search components; scientific equivalence comes from the independently accepted studies, while timing verifies frozen outputs and literal-native pool eligibility",
        failed_times_are_speed_denominators=False,
        source_counts_are_actual=True)
    write(args.output / "acceptance.json", result)
    if problems:
        raise ValueError("Final timing acceptance failed: " + json.dumps(problems))
    return result


class StageRunner:
    def __init__(self, args):
        self.args = args
        self.rows = []
        self.active = None

    def save(self, status):
        write(self.args.output / "status.json", dict(status=status, updated_utc=utc(), stages=self.rows))

    def stop_active(self):
        if self.active is not None and self.active.poll() is None:
            os.killpg(self.active.pid, signal.SIGTERM)
            try:
                self.active.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(self.active.pid, signal.SIGKILL)
                self.active.wait(timeout=10)

    def run(self, name, command, timeout):
        log = self.args.output / "logs" / (name + ".log")
        log.parent.mkdir(parents=True, exist_ok=True)
        row = dict(name=name, command=[str(item) for item in command], timeout_seconds=timeout,
                   status="running", started_utc=utc(), log=str(log.relative_to(self.args.output)))
        self.rows.append(row)
        self.save("running")
        begin = time.monotonic()
        try:
            with log.open("w") as output:
                self.active = subprocess.Popen(row["command"], cwd=self.args.root,
                    stdout=output, stderr=subprocess.STDOUT, env=dict(os.environ,
                    **{name: "1" for name in THREAD_VARS}), start_new_session=True)
                row["pid"] = self.active.pid
                self.save("running")
                exit_code = self.active.wait(timeout=timeout)
            row["exit_code"] = exit_code
            if exit_code:
                raise RuntimeError(f"Stage {name} exited {exit_code}; see {log}")
            row["status"] = "complete"
        except BaseException:
            self.stop_active()
            row.update(status="error", error=traceback.format_exc())
            raise
        finally:
            row.update(elapsed_seconds=time.monotonic()-begin, ended_utc=utc())
            self.active = None
            self.save("running" if row["status"] == "complete" else "error")


def describe(args, corrected_regimes=()):
    tools = timing_tools(args)
    common = ["--manifest", args.manifest, "--paired-results", args.paired_results]
    stages = [dict(name="preflight", timeout_seconds=600, command=[sys.executable, __file__,
        "--root", args.root, *common, "--output", args.output,
        "--timing-tools", tools, "--phase", "preflight"])]
    for backend, regimes in (("candidate", REGIMES), ("gtls", REGIMES),
                              ("gtls_corrected", tuple(corrected_regimes))):
        if not regimes:
            continue
        cmd = [sys.executable, tools / "components.py", *common, "--backend", backend,
               "--output", args.output / "components" / backend, "--regimes", *regimes]
        if backend == "gtls_corrected":
            cmd += ["--correction-adapter", args.root / "validation/corrected_reference.py"]
        stages.append(dict(name="components_" + backend, timeout_seconds=1800, command=cmd))
    stages.append(dict(name="public", timeout_seconds=9000, command=[sys.executable,
        tools / "benchmark.py", *common, "--output", args.output / "public", "--regimes", *REGIMES,
        "--pool-widths", "1", "2", "4", "--timeout", "1200", "--correction-adapter",
        args.root / "validation/corrected_reference.py"]))
    cmd = [sys.executable, tools / "summarize.py", args.output / "public",
        "--components-gtls", args.output / "components/gtls",
        "--components-candidate", args.output / "components/candidate",
        "--output", args.output / "summary.json"]
    if corrected_regimes:
        cmd += ["--components-corrected", args.output / "components/gtls_corrected"]
    stages.append(dict(name="summarize", timeout_seconds=180, command=cmd))
    for row in stages:
        row["command"] = list(map(str, row["command"]))
    return stages


def run(args):
    args.output.mkdir(parents=True, exist_ok=False)
    started = utc()
    runner = StageRunner(args)
    terminal = dict(status="running", started_utc=started, exit_code=None,
                    scope="Timing runner only; independent study acceptance is a prerequisite")
    write(args.output / "terminal.json", terminal)
    exit_code = 2
    try:
        prepared = prepare(args)
        corrected = [regime for regime, item in prepared["selections"].items()
                     if item["correction_timing"]["required"]]
        stages = describe(args, corrected)
        write(args.output / "pipeline-plan.json", dict(stages=stages,
            corrected_regimes=corrected, driver_sha256=sha(__file__),
            expected_duration_minutes=[60, 90],
            conditional_corrected_extra_minutes_at_most_forecast=30,
            timeout_note="Timeouts are failure limits, not cost forecasts; external rental guard remains authoritative"))
        for stage in stages:
            runner.run(stage["name"], stage["command"], stage["timeout_seconds"])
            if stage["name"] == "preflight" and read(args.output / "preflight.json").get("status") != "complete":
                raise ValueError("Preflight did not finish")
            if stage["name"].startswith("components_"):
                backend = stage["name"][len("components_"):]
                check_components(args, backend, corrected if backend == "gtls_corrected" else REGIMES)
        audit(args)
        runner.save("complete")
        terminal.update(status="complete", acceptance="acceptance.json", summary="summary.json",
            acceptance_sha256=sha(args.output / "acceptance.json"),
            summary_sha256=sha(args.output / "summary.json"))
        exit_code = 0
    except BaseException:
        runner.stop_active()
        runner.save("error")
        terminal.update(status="error", error=traceback.format_exc())
        if not (args.output / "acceptance.json").exists():
            write(args.output / "acceptance.json", dict(status="incomplete",
                publication_gate={"pass": False, "problems": ["A required stage did not finish or pass"]},
                failure=terminal["error"]))
    finally:
        terminal.update(exit_code=exit_code, ended_utc=utc())
        write(args.output / "terminal.json", terminal)
    return exit_code


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--paired-results", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--timing-tools", type=Path)
    parser.add_argument("--phase", choices=("all", "preflight"), default="all", help=argparse.SUPPRESS)
    parser.add_argument("--describe", action="store_true", help="Print exact stage commands without executing or requiring completed study files")
    args = parser.parse_args()
    for name in ("root", "manifest", "paired_results", "output"):
        setattr(args, name, getattr(args, name).resolve())
    if args.describe:
        print(json.dumps(dict(stages=describe(args, REGIMES),
            note="Corrected-native stages are included here conditionally; actual execution derives eligibility from accepted correction traces"), indent=2))
        return 0
    for name in THREAD_VARS:
        os.environ[name] = "1"
    def interrupted(signum, _):
        raise InterruptedError("Runner received signal " + str(signum))
    signal.signal(signal.SIGTERM, interrupted)
    if args.phase == "preflight":
        preflight(args)
        return 0
    return run(args)


if __name__ == "__main__":
    raise SystemExit(main())

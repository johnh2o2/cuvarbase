"""CPU-only failure/acceptance checks for the unattended private timing driver."""
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace
import unittest


SPEC = importlib.util.spec_from_file_location("rescue_timing", Path(__file__).with_name("run_timing.py"))
runner = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(runner)


def snapshot(pids=(101,)):
    return dict(allowed_pids=list(pids), observed_pids=list(pids), foreign_pids=[], missing_pids=[], exclusive=True)


def ownership(width=1):
    hosts, workers = list(range(101,101+width)), list(range(11,11+width))
    return dict(version=1, status="complete", passed=True, host_pids=hosts,
        identity_scope="individual" if width == 1 else "owned_pool_set",
        before_start=snapshot(()), after_start=snapshot(hosts), after_exit=snapshot(()),
        owned_worker_pids=workers, live_workers_at_binding=workers,
        workers=[dict(pid=pid, namespace_pids=[pid], cuda_context_allocation_bytes=1,
                      cuda_context_synchronized=True) for pid in workers],
        bindings=[dict(worker_pid=pid, namespace_pids=[pid], host_pid=101 if width == 1 else None,
                       method="single_worker_lifecycle" if width == 1 else "pool_lifecycle_member") for pid in workers],
        worker_exits=[dict(worker_pid=pid, exit_code=0, alive=False, forced=False) for pid in workers])


def measurement(names, width=1):
    return dict(status="ok", errors=[], denominator_seconds=1.0, source_count=len(names),
                outputs=[dict(case=name) for name in names],
                exclusive_before=snapshot(range(101,101+width)), exclusive_after=snapshot(range(101,101+width)))


def configuration(names, width):
    return dict(status="ok", pool_width=width, gpu_ownership=ownership(width), warmup=measurement(names[:1],width),
                single=[measurement(names[:1],width) for _ in range(5)] if width == 1 else [],
                batch=[measurement(names,width) for _ in range(3)])


def component(name):
    return dict(status="ok", gpu_ownership=ownership(), case=dict(name=name), literal_matches_frozen=True,
        literal_outputs=dict(full_digest="frozen"), repetitions=[dict(
            denominator_eligible=True, endpoint_valid=True, output_identical_to_literal=True,
            outputs=dict(full_digest="frozen"), exclusive_before=snapshot(),
            exclusive_after=snapshot()) for _ in range(5)])


def fixture(root, corrected=False, count=16):
    args = SimpleNamespace(root=root, output=root / "timing", manifest=root / "manifest.json",
                           paired_results=root / "main", timing_tools=None)
    selections = {}
    summaries = {}
    for regime in runner.REGIMES:
        names = [f"{regime}_null_{index:04d}.npz" for index in range(count)]
        selections[regime] = dict(selected_cases=names, actual_batch_size=count, single_case=names[0],
            single_replaced=False, excluded_cases=[], correction_timing=dict(required=corrected))
        summaries[regime] = dict(public_single=dict(eligible=True),
            public_batch=dict(eligible=True, source_count=count, strongest_tested_native_workers=1,
                native_pool_configurations={str(width): dict(eligible=width == 1,
                    output_gate=dict(problems=[] if width == 1 else ["Logical union changed"]))
                    for width in (1, 2, 4)}),
            common_search_components=dict(eligible=True))
        if corrected:
            summaries[regime].update(corrected_native_crosscheck=dict(single=dict(eligible=True),
                batch=dict(eligible=True)), corrected_common_search_components=dict(eligible=True))
        configs = [("candidate", 1)] + [("gtls", width) for width in (1, 2, 4) if width <= count]
        if corrected:
            configs.append(("gtls_corrected", 1))
        for backend, width in configs:
            runner.write(args.output / "public" / regime / f"{backend}_graph_{width}worker/record.json",
                         configuration(names, width))
    prepared = dict(manifest_sha256="manifest", selections=selections, frozen_outputs={})
    runner.write(args.output / "prepared.json", prepared)
    runner.write(args.output / "public/plan.json", dict(measurement_scope="full", manifest_sha256="manifest",
        regimes=list(runner.REGIMES), single_repetitions=5, batch_repetitions=3,
        native_pool_widths=[1, 2, 4], cohort_selection=selections, frozen_outputs={}))
    runner.write(args.output / "summary.json", dict(regimes=summaries))
    runner.write(args.output / "timing_analysis.json", dict(measurement_scope="single_and_batch",
        verification=dict(complete=True), timings=[dict(mode=mode, repetitions=5 if mode == "single" else 3)
        for mode in ("single", "batch") for _ in range(6)]))
    return args


class TimingChecks(unittest.TestCase):
    def test_successful_configuration(self):
        names = ["a", "b", "c", "d"]
        for width in (1, 2, 4):
            self.assertEqual(runner.measured_configuration_problems(configuration(names, width),
                names, names[0], width), [])

    def test_missing_context_exit_or_changed_pool_count_rejected(self):
        for change in ("exit", "count", "host_set"):
            record = configuration(["a", "b", "c", "d"], 2)
            if change == "exit":
                del record["gpu_ownership"]["after_exit"]
            elif change == "count":
                record["pool_width"] = 4
            else:
                record["batch"][0]["exclusive_after"] = snapshot([101,103])
            self.assertTrue(runner.measured_configuration_problems(record,["a","b","c","d"],"a",2))

    def test_normalized_scope_or_repetition_changes_are_rejected(self):
        for change in ("scope", "missing", "repetitions"):
            with TemporaryDirectory() as folder:
                args = fixture(Path(folder))
                path=args.output / "timing_analysis.json"
                record=runner.read(path)
                if change == "scope": record["measurement_scope"] = "single"
                elif change == "missing": record["timings"].pop()
                else: record["timings"][0]["repetitions"] = 3
                runner.write(path,record)
                with self.assertRaisesRegex(ValueError,"Normalized"):
                    runner.audit(args)

    def test_missing_repetition_rejected(self):
        record = configuration(["a", "b"], 1)
        record["batch"].pop()
        self.assertTrue(runner.measured_configuration_problems(record, ["a", "b"], "a", 1))

    def test_failed_elapsed_never_denominator(self):
        record = configuration(["a", "b"], 1)
        record["batch"][0].update(status="error", denominator_seconds=None)
        self.assertTrue(runner.measured_configuration_problems(record, ["a", "b"], "a", 1))

    def test_changed_case_and_wrong_denominator_rejected(self):
        for mutate in (lambda row: row.update(source_count=16),
                       lambda row: row["outputs"][0].update(case="another")):
            record = configuration(["a", "b"], 1)
            mutate(record["batch"][0])
            self.assertTrue(runner.measured_configuration_problems(record, ["a", "b"], "a", 1))

    def test_foreign_process_rejected(self):
        record = configuration(["a", "b"], 1)
        record["single"][0]["exclusive_after"]["exclusive"] = False
        self.assertTrue(runner.measured_configuration_problems(record, ["a", "b"], "a", 1))

    def test_component_endpoints_and_literal_identity(self):
        self.assertEqual(runner.component_problems(component("a"), "a"), [])
        for key in ("endpoint_valid", "output_identical_to_literal", "denominator_eligible"):
            record = component("a")
            record["repetitions"][0][key] = False
            self.assertTrue(runner.component_problems(record, "a"))
        record = component("a")
        record["repetitions"][0]["outputs"]["full_digest"] = "changed"
        self.assertTrue(runner.component_problems(record, "a"))

    def test_accepts_complete_gated_protocol_with_excluded_parallel_pools(self):
        with TemporaryDirectory() as folder:
            args = fixture(Path(folder))
            result = runner.audit(args)
            self.assertTrue(result["publication_gate"]["pass"])
            self.assertFalse(result["regimes"]["tess_solar"]["pool_eligibility"]["4"]["eligible"])

    def test_actual_smaller_cohort_is_explicit(self):
        with TemporaryDirectory() as folder:
            args = fixture(Path(folder), count=8)
            result = runner.audit(args)
            self.assertTrue(result["publication_gate"]["pass"])
            self.assertEqual(result["regimes"]["tess_gap"]["actual_batch_size"], 8)

    def test_missing_required_configuration_rejected(self):
        with TemporaryDirectory() as folder:
            args = fixture(Path(folder))
            (args.output / "public/ztf_solar/gtls_graph_4worker/record.json").unlink()
            with self.assertRaisesRegex(ValueError, "Missing required configuration"):
                runner.audit(args)
            self.assertFalse(runner.read(args.output / "acceptance.json")["publication_gate"]["pass"])

    def test_changed_preflight_cohort_rejected(self):
        with TemporaryDirectory() as folder:
            args = fixture(Path(folder))
            path = args.output / "public/plan.json"
            plan = runner.read(path)
            plan["cohort_selection"]["tess_gap"]["single_case"] = "later"
            runner.write(path, plan)
            with self.assertRaisesRegex(ValueError, "Cohort or acceptance chain changed"):
                runner.audit(args)

    def test_conditional_corrected_gates_required(self):
        with TemporaryDirectory() as folder:
            args = fixture(Path(folder), corrected=True)
            self.assertTrue(runner.audit(args)["publication_gate"]["pass"])
            summary = runner.read(args.output / "summary.json")
            summary["regimes"]["ztf_solar"]["corrected_common_search_components"]["eligible"] = False
            runner.write(args.output / "summary.json", summary)
            with self.assertRaisesRegex(ValueError, "Corrected-native common-search gate failed"):
                runner.audit(args)

    def test_failed_preparation_writes_terminal_receipt_without_gpu(self):
        with TemporaryDirectory() as folder:
            root = Path(folder)
            args = SimpleNamespace(root=root, output=root / "timing", manifest=root / "absent.json",
                                   paired_results=root / "main", timing_tools=None)
            self.assertEqual(runner.run(args), 2)
            terminal = runner.read(args.output / "terminal.json")
            self.assertEqual((terminal["status"], terminal["exit_code"]), ("error", 2))
            self.assertFalse(runner.read(args.output / "acceptance.json")["publication_gate"]["pass"])

    def test_stage_nonzero_preserved(self):
        with TemporaryDirectory() as folder:
            args = SimpleNamespace(root=Path(folder), output=Path(folder) / "timing")
            stage = runner.StageRunner(args)
            with self.assertRaisesRegex(RuntimeError, "exited 4"):
                stage.run("deliberate_failure", [sys.executable, "-c", "raise SystemExit(4)"], 10)
            record = runner.read(args.output / "status.json")
            self.assertEqual(record["stages"][0]["exit_code"], 4)
            self.assertEqual(record["status"], "error")

    def test_stage_timeout_kills_only_owned_group(self):
        with TemporaryDirectory() as folder:
            args = SimpleNamespace(root=Path(folder), output=Path(folder) / "timing")
            stage = runner.StageRunner(args)
            with self.assertRaises(subprocess.TimeoutExpired):
                stage.run("deliberate_timeout", [sys.executable, "-c", "import time; time.sleep(30)"], .05)
            self.assertEqual(runner.read(args.output / "status.json")["status"], "error")
            self.assertIsNone(stage.active)

    def test_describe_keeps_declared_repetitions_pools_and_conditional_adapter(self):
        root = Path(__file__).resolve().parents[1]
        args = SimpleNamespace(root=root, output=root / "rescue/results/timing",
            manifest=root / "rescue/results/timing_manifest.json", paired_results=root / "rescue/results/main",
            timing_tools=Path(__file__).parent / "tools/timing")
        stages = runner.describe(args)
        self.assertNotIn("components_gtls_corrected", [item["name"] for item in stages])
        public = next(item for item in stages if item["name"] == "public")
        self.assertIn("--pool-widths", public["command"])
        self.assertNotIn("--row-ab", public["command"])
        stages = runner.describe(args, ["ztf_solar"])
        corrected = next(item for item in stages if item["name"] == "components_gtls_corrected")
        self.assertEqual(corrected["command"][-2:], ["--correction-adapter", str(root / "validation/corrected_reference.py")])


if __name__ == "__main__":
    unittest.main()
